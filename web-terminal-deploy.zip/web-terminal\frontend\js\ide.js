/* ==========================================================================
   Web Terminal — IDE Logic
   ========================================================================== */

(function () {
  'use strict';

  /* ---------- DOM References ---------- */
  var fileTreeEl = document.getElementById('fileTree');
  var breadcrumbEl = document.getElementById('breadcrumb');
  var tabBarEl = document.getElementById('tabBar');
  var editorEl = document.getElementById('editor');
  var statusPath = document.getElementById('statusPath');
  var statusCursor = document.getElementById('statusCursor');
  var statusLang = document.getElementById('statusLang');
  var statusSize = document.getElementById('statusSize');
  var toastContainer = document.getElementById('toastContainer');
  var fileInput = document.getElementById('fileInput');
  var sidebarEl = document.getElementById('sidebar');
  var sidebarResizer = document.getElementById('sidebarResizer');

  /* ---------- State ---------- */
  var editor = null;
  var openTabs = [];
  var activeTabIndex = -1;
  var currentPath = '';          // current directory in file tree
  var expandedDirs = {};         // path -> true
  var contextMenuEl = null;
  var contextTargetPath = null;
  var contextTargetIsDir = false;
  var uploadTargetDir = '';
  var monacoReady = false;

  /* Extension -> language mapping */
  var LANG_MAP = {
    '.js': 'javascript', '.mjs': 'javascript', '.jsx': 'javascript',
    '.ts': 'typescript', '.tsx': 'typescript',
    '.py': 'python',
    '.html': 'html', '.htm': 'html',
    '.css': 'css', '.scss': 'scss', '.less': 'less',
    '.json': 'json',
    '.md': 'markdown', '.markdown': 'markdown',
    '.sh': 'shell', '.bash': 'shell',
    '.go': 'go',
    '.rs': 'rust',
    '.java': 'java',
    '.c': 'c', '.h': 'c',
    '.cpp': 'cpp', '.cc': 'cpp', '.cxx': 'cpp', '.hpp': 'cpp',
    '.sql': 'sql',
    '.xml': 'xml', '.svg': 'xml',
    '.yaml': 'yaml', '.yml': 'yaml',
    '.php': 'php',
    '.rb': 'ruby',
    '.swift': 'swift',
    '.kt': 'kotlin',
    '.dart': 'dart',
    '.lua': 'lua',
    '.dockerfile': 'dockerfile',
    '.ini': 'ini',
    '.toml': 'ini',
    '.txt': 'plaintext',
    '.log': 'plaintext'
  };

  /* Extension -> CSS class for icon color */
  var ICON_CLASS_MAP = {
    '.js': 'js', '.mjs': 'js', '.jsx': 'js',
    '.ts': 'ts', '.tsx': 'ts',
    '.py': 'py',
    '.html': 'html', '.htm': 'html',
    '.css': 'css', '.scss': 'css', '.less': 'css',
    '.json': 'json',
    '.md': 'md', '.markdown': 'md',
    '.sh': 'sh', '.bash': 'sh',
    '.go': 'go',
    '.rs': 'rs',
    '.java': 'java',
    '.c': 'c', '.h': 'c',
    '.cpp': 'cpp', '.cc': 'cpp', '.cxx': 'cpp', '.hpp': 'cpp',
    '.sql': 'sql',
    '.xml': 'xml', '.svg': 'xml',
    '.yaml': 'yaml', '.yml': 'yaml'
  };

  /* ---------- Auth ---------- */
  function getToken() {
    var token = localStorage.getItem('wt_token');
    if (!token) {
      window.location.href = '/';
      return null;
    }
    return token;
  }

  function apiFetch(url, opts) {
    opts = opts || {};
    opts.headers = opts.headers || {};
    opts.headers['Authorization'] = 'Bearer ' + getToken();
    return fetch(url, opts);
  }

  /* ---------- Toast ---------- */
  function toast(msg, type) {
    var el = document.createElement('div');
    el.className = 'toast ' + (type || 'info');
    el.textContent = msg;
    toastContainer.appendChild(el);
    setTimeout(function () {
      el.classList.add('fade-out');
      setTimeout(function () { el.remove(); }, 300);
    }, 3000);
  }

  /* ---------- Utility ---------- */
  function getExt(name) {
    var lower = name.toLowerCase();
    if (lower === 'dockerfile' || lower === 'makefile' || lower === 'gemfile') {
      return '.' + lower;
    }
    var idx = lower.lastIndexOf('.');
    return idx >= 0 ? lower.substring(idx) : '';
  }

  function getLanguage(path) {
    var name = path.split('/').pop();
    var ext = getExt(name);
    if (ext === '.dockerfile') return 'dockerfile';
    return LANG_MAP[ext] || 'plaintext';
  }

  function getIconClass(name) {
    var ext = getExt(name);
    return ICON_CLASS_MAP[ext] || 'default';
  }

  function baseName(path) {
    var parts = path.replace(/\/$/, '').split('/');
    return parts[parts.length - 1] || '/';
  }

  function dirName(path) {
    var parts = path.replace(/\/$/, '').split('/');
    parts.pop();
    return parts.join('/') || '/';
  }

  function joinPath(base, name) {
    if (base === '' || base === '/') return '/' + name;
    return base.replace(/\/$/, '') + '/' + name;
  }

  function formatSize(bytes) {
    if (bytes === 0) return '0 B';
    var units = ['B', 'KB', 'MB', 'GB'];
    var i = Math.floor(Math.log(bytes) / Math.log(1024));
    return parseFloat((bytes / Math.pow(1024, i)).toFixed(1)) + ' ' + units[i];
  }

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  /* ---------- File Tree Rendering ---------- */
  function renderBreadcrumb(path) {
    breadcrumbEl.innerHTML = '';
    var parts = path.replace(/^\/+/, '').split('/').filter(Boolean);
    var crumb = document.createElement('span');
    crumb.className = 'breadcrumb-item';
    crumb.textContent = '/';
    crumb.addEventListener('click', function () {
      currentPath = '';
      loadFiles('');
    });
    breadcrumbEl.appendChild(crumb);

    var accum = '';
    parts.forEach(function (part, i) {
      accum += '/' + part;
      var sep = document.createElement('span');
      sep.className = 'breadcrumb-sep';
      sep.textContent = '›';
      breadcrumbEl.appendChild(sep);

      var item = document.createElement('span');
      item.className = 'breadcrumb-item';
      item.textContent = part;
      (function (p) {
        item.addEventListener('click', function () {
          currentPath = p;
          loadFiles(p);
        });
      })(accum);
      breadcrumbEl.appendChild(item);
    });
  }

  function loadFiles(path) {
    currentPath = path || '';
    renderBreadcrumb(currentPath);
    apiFetch('/api/files/list?path=' + encodeURIComponent(currentPath))
      .then(function (r) {
        if (r.status === 401 || r.status === 403) {
          window.location.href = '/';
          return null;
        }
        return r.json();
      })
      .then(function (items) {
        if (!items) return;
        renderTree(items, 0);
      })
      .catch(function (err) {
        toast('Failed to load files: ' + err.message, 'error');
      });
  }

  function renderTree(items, depth) {
    // Sort: directories first, then alphabetical
    items.sort(function (a, b) {
      if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    renderTreeItems(items, depth, fileTreeEl);
  }

  function renderTreeItems(items, depth, container) {
    items.forEach(function (item) {
      var el = document.createElement('div');
      el.className = 'file-item' + (item.isDir ? ' folder' : '');
      el.dataset.path = item.path;

      /* Indent */
      el.style.paddingLeft = (8 + depth * 14) + 'px';

      /* Arrow for folders */
      var arrow = document.createElement('span');
      arrow.className = 'arrow' + (item.isDir ? '' : ' spacer');
      arrow.textContent = '▶';
      el.appendChild(arrow);

      /* Icon */
      var icon = document.createElement('span');
      icon.className = 'icon ' + (item.isDir ? 'folder' : getIconClass(item.name));
      if (item.isDir) {
        icon.innerHTML = '📁';
      } else {
        icon.innerHTML = '📄';
      }
      el.appendChild(icon);

      /* Name */
      var name = document.createElement('span');
      name.className = 'name';
      name.textContent = item.name;
      el.appendChild(name);

      /* Click handler */
      if (item.isDir) {
        arrow.addEventListener('click', function (e) {
          e.stopPropagation();
          toggleFolder(item, el, arrow, depth);
        });
        el.addEventListener('click', function (e) {
          if (e.target !== arrow) {
            toggleFolder(item, el, arrow, depth);
          }
        });
      } else {
        el.addEventListener('click', function () {
          openInEditor(item.path);
          document.querySelectorAll('.file-item.selected').forEach(function (n) {
            n.classList.remove('selected');
          });
          el.classList.add('selected');
        });
      }

      /* Right-click context menu */
      el.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        e.stopPropagation();
        contextTargetPath = item.path;
        contextTargetIsDir = !!item.isDir;
        showContextMenu(e.clientX, e.clientY, item);
      });

      container.appendChild(el);
    });
  }

  function toggleFolder(item, el, arrow, depth) {
    if (expandedDirs[item.path]) {
      /* Collapse */
      expandedDirs[item.path] = false;
      arrow.classList.remove('expanded');
      var next = el.nextElementSibling;
      while (next && next.dataset.depth > depth) {
        next.remove();
        next = el.nextElementSibling;
      }
    } else {
      /* Expand */
      expandedDirs[item.path] = true;
      arrow.classList.add('expanded');
      loadSubdirectory(item.path, el, depth + 1);
    }
  }

  function loadSubdirectory(path, parentEl, depth) {
    apiFetch('/api/files/list?path=' + encodeURIComponent(path))
      .then(function (r) { return r.json(); })
      .then(function (items) {
        if (!items) return;
        items.sort(function (a, b) {
          if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
          return a.name.localeCompare(b.name);
        });
        var fragment = document.createDocumentFragment();
        items.forEach(function (item) {
          var el = createFileItemEl(item, depth);
          fragment.appendChild(el);
        });
        parentEl.after(fragment);
      })
      .catch(function (err) {
        toast('Failed to load directory: ' + err.message, 'error');
      });
  }

  function createFileItemEl(item, depth) {
    var el = document.createElement('div');
    el.className = 'file-item' + (item.isDir ? ' folder' : '');
    el.dataset.path = item.path;
    el.dataset.depth = depth;
    el.style.paddingLeft = (8 + depth * 14) + 'px';

    var arrow = document.createElement('span');
    arrow.className = 'arrow' + (item.isDir ? '' : ' spacer');
    arrow.textContent = '▶';
    el.appendChild(arrow);

    var icon = document.createElement('span');
    icon.className = 'icon ' + (item.isDir ? 'folder' : getIconClass(item.name));
    icon.innerHTML = item.isDir ? '📁' : '📄';
    el.appendChild(icon);

    var name = document.createElement('span');
    name.className = 'name';
    name.textContent = item.name;
    el.appendChild(name);

    if (item.isDir) {
      arrow.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleFolder(item, el, arrow, depth);
      });
      el.addEventListener('click', function (e) {
        if (e.target !== arrow) {
          toggleFolder(item, el, arrow, depth);
        }
      });
    } else {
      el.addEventListener('click', function () {
        openInEditor(item.path);
        document.querySelectorAll('.file-item.selected').forEach(function (n) {
          n.classList.remove('selected');
        });
        el.classList.add('selected');
      });
    }

    el.addEventListener('contextmenu', function (e) {
      e.preventDefault();
      e.stopPropagation();
      contextTargetPath = item.path;
      contextTargetIsDir = !!item.isDir;
      showContextMenu(e.clientX, e.clientY, item);
    });

    return el;
  }

  /* ---------- Context Menu ---------- */
  function showContextMenu(x, y, item) {
    hideContextMenu();
    var menu = document.createElement('div');
    menu.className = 'context-menu';

    var targetDir = contextTargetIsDir ? contextTargetPath : dirName(contextTargetPath);
    if (targetDir === '.') targetDir = '';

    addMenuItem(menu, 'New File', 'newFile', function () {
      promptNewFile(targetDir);
    });
    addMenuItem(menu, 'New Folder', 'newFolder', function () {
      promptNewFolder(targetDir);
    });
    addMenuSeparator(menu);
    addMenuItem(menu, 'Rename', 'rename', function () {
      promptRename(contextTargetPath);
    });
    addMenuItem(menu, 'Delete', 'delete', true, function () {
      doDelete(contextTargetPath);
    });
    addMenuSeparator(menu);
    if (!contextTargetIsDir) {
      addMenuItem(menu, 'Download', 'download', function () {
        window.open('/api/files/download?path=' + encodeURIComponent(contextTargetPath) +
          '&token=' + encodeURIComponent(getToken()), '_blank');
      });
    }
    addMenuItem(menu, 'Upload Here', 'upload', function () {
      uploadTargetDir = targetDir;
      fileInput.click();
    });

    menu.style.left = Math.min(x, window.innerWidth - 180) + 'px';
    menu.style.top = Math.min(y, window.innerHeight - 280) + 'px';
    document.body.appendChild(menu);
    contextMenuEl = menu;
  }

  function addMenuItem(menu, label, key, isDanger, handler) {
    /* Support overload: addMenuItem(menu, label, key, handler) */
    if (typeof isDanger === 'function') {
      handler = isDanger;
      isDanger = false;
    }
    var item = document.createElement('div');
    item.className = 'context-menu-item' + (isDanger ? ' danger' : '');
    item.textContent = label;
    item.addEventListener('click', function () {
      hideContextMenu();
      handler();
    });
    menu.appendChild(item);
  }

  function addMenuSeparator(menu) {
    var sep = document.createElement('div');
    sep.className = 'context-menu-separator';
    menu.appendChild(sep);
  }

  function hideContextMenu() {
    if (contextMenuEl) {
      contextMenuEl.remove();
      contextMenuEl = null;
    }
  }

  document.addEventListener('click', function () { hideContextMenu(); });
  document.addEventListener('contextmenu', function (e) {
    /* If right-click outside file tree, show menu for current dir */
    if (!e.target.closest('.file-item') && !e.target.closest('.context-menu')) {
      e.preventDefault();
      contextTargetPath = currentPath;
      contextTargetIsDir = true;
      showContextMenu(e.clientX, e.clientY, null);
    }
  });

  /* ---------- File Operations ---------- */
  function promptNewFile(dir) {
    var name = prompt('Enter new file name:');
    if (!name) return;
    var fullPath = joinPath(dir, name);
    apiFetch('/api/files/write', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: fullPath, content: '' })
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data.success !== false) {
          toast('File created: ' + name, 'success');
          loadFiles(currentPath);
        } else {
          toast('Failed to create file', 'error');
        }
      })
      .catch(function (err) {
        toast('Error: ' + err.message, 'error');
      });
  }

  function promptNewFolder(dir) {
    var name = prompt('Enter new folder name:');
    if (!name) return;
    var fullPath = joinPath(dir, name);
    apiFetch('/api/files/mkdir', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: fullPath })
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data.success !== false) {
          toast('Folder created: ' + name, 'success');
          loadFiles(currentPath);
        } else {
          toast('Failed to create folder', 'error');
        }
      })
      .catch(function (err) {
        toast('Error: ' + err.message, 'error');
      });
  }

  function promptRename(oldPath) {
    var oldName = baseName(oldPath);
    var newName = prompt('Rename to:', oldName);
    if (!newName || newName === oldName) return;
    var newPath = joinPath(dirName(oldPath), newName);
    apiFetch('/api/files/rename', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ oldPath: oldPath, newPath: newPath })
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data.success !== false) {
          toast('Renamed to ' + newName, 'success');
          loadFiles(currentPath);
          /* Update open tab if it was the renamed file */
          var tab = findTabByPath(oldPath);
          if (tab) {
            tab.path = newPath;
            tab.name = newName;
            renderTabs();
          }
        } else {
          toast('Failed to rename', 'error');
        }
      })
      .catch(function (err) {
        toast('Error: ' + err.message, 'error');
      });
  }

  function doDelete(path) {
    if (!confirm('Delete "' + baseName(path) + '"? This cannot be undone.')) return;
    apiFetch('/api/files/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: path })
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data.success !== false) {
          toast('Deleted: ' + baseName(path), 'success');
          loadFiles(currentPath);
          /* Close any open tab for this path */
          var tab = findTabByPath(path);
          if (tab) {
            closeTab(openTabs.indexOf(tab), true);
          }
        } else {
          toast('Failed to delete', 'error');
        }
      })
      .catch(function (err) {
        toast('Error: ' + err.message, 'error');
      });
  }

  /* ---------- Upload ---------- */
  fileInput.addEventListener('change', function () {
    var files = fileInput.files;
    if (!files || files.length === 0) return;
    uploadFiles(files, uploadTargetDir || currentPath);
    fileInput.value = '';
  });

  function uploadFiles(files, dir) {
    var completed = 0;
    var total = files.length;
    Array.prototype.forEach.call(files, function (file) {
      var formData = new FormData();
      formData.append('file', file);
      formData.append('path', dir);

      /* Can't use apiFetch for FormData (browser sets content-type + boundary) */
      fetch('/api/files/upload', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + getToken() },
        body: formData
      })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data.success !== false) {
            completed++;
            if (completed === total) {
              toast('Uploaded ' + total + ' file' + (total > 1 ? 's' : ''), 'success');
              loadFiles(currentPath);
            }
          } else {
            toast('Failed to upload ' + file.name, 'error');
          }
        })
        .catch(function (err) {
          toast('Upload error: ' + err.message, 'error');
        });
    });
  }

  /* ---------- Monaco Editor ---------- */
  function initMonaco() {
    require.config({
      paths: { 'vs': 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs' }
    });

    require(['vs/editor/editor.main'], function () {
      monaco.editor.defineTheme('wt-dark', {
        base: 'vs-dark',
        inherit: true,
        rules: [],
        colors: {
          'editor.background': '#0d1117',
          'editor.foreground': '#e6edf3',
          'editorLineNumber.foreground': '#6e7681',
          'editorLineNumber.activeForeground': '#e6edf3',
          'editor.selectionBackground': '#264f78',
          'editor.lineHighlightBackground': '#161b22',
          'editorCursor.foreground': '#58a6ff',
          'editorIndentGuide.background': '#21262d',
          'editorIndentGuide.activeBackground': '#30363d',
          'editorWidget.background': '#161b22',
          'editorWidget.border': '#30363d',
          'editorSuggestWidget.background': '#161b22',
          'editorSuggestWidget.border': '#30363d',
          'editorSuggestWidget.selectedBackground': '#1f6feb33',
          'scrollbarSlider.background': '#30363d80',
          'scrollbarSlider.hoverBackground': '#30363d',
          'scrollbarSlider.activeBackground': '#484f58'
        }
      });

      editor = monaco.editor.create(editorEl, {
        value: '',
        language: 'plaintext',
        theme: 'wt-dark',
        fontSize: 14,
        fontFamily: "'Fira Code', 'JetBrains Mono', 'Source Code Pro', monospace",
        fontLigatures: true,
        minimap: { enabled: true },
        wordWrap: 'on',
        lineNumbers: 'on',
        automaticLayout: true,
        scrollBeyondLastLine: false,
        smoothScrolling: true,
        cursorBlinking: 'smooth',
        cursorSmoothCaretAnimation: 'on',
        renderWhitespace: 'selection',
        tabSize: 2,
        padding: { top: 8, bottom: 8 }
      });

      monacoReady = true;

      /* Content change -> mark dirty */
      editor.onDidChangeModelContent(function () {
        var tab = getActiveTab();
        if (tab) {
          var model = editor.getModel();
          if (model) {
            tab.content = model.getValue();
          }
          if (tab.content !== tab.savedContent) {
            tab.isDirty = true;
          } else {
            tab.isDirty = false;
          }
          renderTabs();
        }
      });

      /* Cursor position -> status bar */
      editor.onDidChangeCursorPosition(function (e) {
        statusCursor.textContent = 'Ln ' + (e.position.lineNumber) + ', Col ' + (e.position.column);
      });

      /* Ctrl+S to save */
      editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, function () {
        saveCurrentTab();
      });

      /* Now that editor is ready, load files */
      loadFiles('');
    });
  }

  function getActiveTab() {
    if (activeTabIndex >= 0 && activeTabIndex < openTabs.length) {
      return openTabs[activeTabIndex];
    }
    return null;
  }

  function findTabByPath(path) {
    for (var i = 0; i < openTabs.length; i++) {
      if (openTabs[i].path === path) return openTabs[i];
    }
    return null;
  }

  function openInEditor(path) {
    if (!monacoReady) {
      toast('Editor not ready yet, please wait…', 'info');
      return;
    }

    /* If tab already open, switch to it */
    var existing = findTabByPath(path);
    if (existing) {
      switchToTab(openTabs.indexOf(existing));
      return;
    }

    /* Read file content */
    apiFetch('/api/files/read?path=' + encodeURIComponent(path))
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(function (data) {
        var lang = getLanguage(path);
        var name = baseName(path);
        var content = data.content || '';

        /* Create Monaco model */
        var model = monaco.editor.createModel(content, lang);

        var tab = {
          path: path,
          name: name,
          model: model,
          isDirty: false,
          content: content,
          savedContent: content,
          language: lang,
          size: data.size || content.length
        };

        openTabs.push(tab);
        switchToTab(openTabs.length - 1);
        toast('Opened: ' + name, 'info');
      })
      .catch(function (err) {
        toast('Failed to open file: ' + err.message, 'error');
      });
  }

  function switchToTab(index) {
    if (index < 0 || index >= openTabs.length) return;
    activeTabIndex = index;
    var tab = openTabs[index];
    editor.setModel(tab.model);
    renderTabs();
    updateStatusBar(tab);
  }

  function updateStatusBar(tab) {
    if (!tab) {
      statusPath.textContent = 'No file open';
      statusCursor.textContent = 'Ln 1, Col 1';
      statusLang.textContent = '—';
      statusSize.textContent = '0 B';
      return;
    }
    statusPath.textContent = tab.path;
    statusLang.textContent = tab.language;
    statusSize.textContent = formatSize(tab.size || 0);
    var pos = editor.getPosition();
    if (pos) {
      statusCursor.textContent = 'Ln ' + pos.lineNumber + ', Col ' + pos.column;
    }
  }

  function renderTabs() {
    tabBarEl.innerHTML = '';
    if (openTabs.length === 0) {
      updateStatusBar(null);
      return;
    }

    openTabs.forEach(function (tab, i) {
      var el = document.createElement('div');
      el.className = 'tab' + (i === activeTabIndex ? ' active' : '') + (tab.isDirty ? ' dirty' : '');

      /* Icon */
      var icon = document.createElement('span');
      icon.className = 'tab-icon';
      icon.innerHTML = '📄';
      el.appendChild(icon);

      /* Name */
      var name = document.createElement('span');
      name.className = 'tab-name';
      name.textContent = tab.name;
      el.appendChild(name);

      /* Close button */
      var close = document.createElement('span');
      close.className = 'close';
      close.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
      close.addEventListener('click', function (e) {
        e.stopPropagation();
        closeTab(i, false);
      });
      el.appendChild(close);

      /* Click to switch */
      el.addEventListener('click', function () {
        switchToTab(i);
      });

      /* Middle-click to close */
      el.addEventListener('mousedown', function (e) {
        if (e.button === 1) {
          e.preventDefault();
          closeTab(i, false);
        }
      });

      tabBarEl.appendChild(el);
    });
  }

  function closeTab(index, force) {
    if (index < 0 || index >= openTabs.length) return;
    var tab = openTabs[index];

    if (tab.isDirty && !force) {
      if (!confirm('"' + tab.name + '" has unsaved changes. Close anyway?')) {
        return;
      }
    }

    /* Dispose model */
    if (tab.model) {
      tab.model.dispose();
    }

    openTabs.splice(index, 1);

    /* Determine next active tab */
    if (openTabs.length === 0) {
      activeTabIndex = -1;
      if (editor) {
        editor.setModel(monaco.editor.createModel('', 'plaintext'));
      }
      updateStatusBar(null);
    } else {
      if (index <= activeTabIndex) {
        activeTabIndex--;
      }
      if (activeTabIndex < 0) activeTabIndex = 0;
      switchToTab(activeTabIndex);
    }

    renderTabs();
  }

  function saveCurrentTab() {
    var tab = getActiveTab();
    if (!tab) {
      toast('No file to save', 'info');
      return;
    }

    var content = '';
    if (tab.model) {
      content = tab.model.getValue();
    }

    apiFetch('/api/files/write', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: tab.path, content: content })
    })
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(function (data) {
        if (data.success !== false) {
          tab.isDirty = false;
          tab.savedContent = content;
          tab.content = content;
          tab.size = data.size || content.length;
          renderTabs();
          updateStatusBar(tab);
          toast('Saved: ' + tab.name, 'success');
        } else {
          toast('Failed to save file', 'error');
        }
      })
      .catch(function (err) {
        toast('Save error: ' + err.message, 'error');
      });
  }

  /* ---------- Sidebar Resizer ---------- */
  var isResizing = false;
  var startX = 0;
  var startWidth = 0;

  sidebarResizer.addEventListener('mousedown', function (e) {
    isResizing = true;
    startX = e.clientX;
    startWidth = sidebarEl.offsetWidth;
    sidebarResizer.classList.add('dragging');
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    e.preventDefault();
  });

  document.addEventListener('mousemove', function (e) {
    if (!isResizing) return;
    var newWidth = startWidth + (e.clientX - startX);
    if (newWidth >= 150 && newWidth <= 500) {
      sidebarEl.style.width = newWidth + 'px';
    }
  });

  document.addEventListener('mouseup', function () {
    if (isResizing) {
      isResizing = false;
      sidebarResizer.classList.remove('dragging');
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    }
  });

  /* ---------- Top Bar Buttons ---------- */
  document.getElementById('logoutBtn').addEventListener('click', function () {
    fetch('/api/logout', { method: 'POST', credentials: 'include' })
      .catch(function () { /* proceed anyway */ })
      .finally(function () {
        localStorage.removeItem('wt_token');
        window.location.href = '/';
      });
  });

  document.getElementById('settingsBtn').addEventListener('click', function () {
    window.location.href = '/terminal.html';
  });

  /* ---------- Sidebar Toolbar Buttons ---------- */
  document.getElementById('refreshBtn').addEventListener('click', function () {
    expandedDirs = {};
    loadFiles(currentPath);
    toast('Refreshed', 'info');
  });

  document.getElementById('newFileBtn').addEventListener('click', function () {
    promptNewFile(currentPath);
  });

  document.getElementById('newFolderBtn').addEventListener('click', function () {
    promptNewFolder(currentPath);
  });

  document.getElementById('uploadBtn').addEventListener('click', function () {
    uploadTargetDir = currentPath;
    fileInput.click();
  });

  /* ---------- Keyboard Shortcuts ---------- */
  document.addEventListener('keydown', function (e) {
    /* Ctrl/Cmd+S handled by Monaco, but also catch here for fallback */
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      if (monacoReady && editor) return; /* Monaco handles it */
      saveCurrentTab();
    }

    /* Ctrl+W to close tab (browsers may intercept, try anyway) */
    if ((e.ctrlKey || e.metaKey) && e.key === 'w') {
      e.preventDefault();
      if (activeTabIndex >= 0) {
        closeTab(activeTabIndex, false);
      }
    }

    /* Ctrl+Tab to switch tabs */
    if (e.ctrlKey && e.key === 'Tab') {
      e.preventDefault();
      if (openTabs.length > 1) {
        var next = (activeTabIndex + 1) % openTabs.length;
        switchToTab(next);
      }
    }
  });

  /* ---------- Window Resize ---------- */
  window.addEventListener('resize', function () {
    if (editor && monacoReady) {
      editor.layout();
    }
  });

  /* ---------- Init ---------- */
  function init() {
    if (!getToken()) return;
    initMonaco();
  }

  init();
})();
