// server.js - Main HTTP + WebSocket server for the web terminal.
const http = require('http');
const path = require('path');
const fs = require('fs');
const express = require('express');
const cookieParser = require('cookie-parser');
const { WebSocketServer } = require('ws');
const url = require('url');

const config = require('./config');
const auth = require('./auth');
const tmux = require('./tmux');

const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');
const cfg = config.getConfig();
const PORT = process.env.PORT || cfg.port || 3000;
const SESSION_NAME = cfg.sessionName || 'main';

const app = express();

app.use(express.json());
app.use(cookieParser());

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.header('Access-Control-Allow-Credentials', 'true');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

function requireAuth(req, res, next) {
  const decoded = auth.verifyRequest(req);
  if (!decoded) return res.status(401).json({ error: 'Unauthorized' });
  req.user = decoded;
  next();
}

// ----- Auth routes -----
app.post('/api/login', (req, res) => {
  const { password } = req.body || {};
  if (typeof password !== 'string') return res.status(400).json({ error: 'Password is required' });
  const result = auth.login(password);
  if (!result.success) return res.status(401).json({ error: result.error });
  res.cookie('token', result.token, { httpOnly: true, sameSite: 'lax', maxAge: 7 * 24 * 60 * 60 * 1000 });
  return res.json({ success: true, token: result.token, expiresIn: result.expiresIn });
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('token');
  return res.json({ success: true });
});

app.post('/api/change-password', requireAuth, (req, res) => {
  const { oldPassword, newPassword } = req.body || {};
  if (typeof oldPassword !== 'string' || typeof newPassword !== 'string') {
    return res.status(400).json({ error: 'oldPassword and newPassword are required' });
  }
  const result = auth.changePassword(oldPassword, newPassword);
  if (!result.success) return res.status(400).json({ error: result.error });
  return res.json({ success: true });
});

// ----- Config routes -----
app.get('/api/config', requireAuth, (req, res) => {
  const c = config.getConfig();
  const { password, ...safe } = c;
  return res.json(safe);
});

app.post('/api/config', requireAuth, (req, res) => {
  const updates = req.body || {};
  if ('password' in updates) return res.status(400).json({ error: 'Use /api/change-password' });
  const updated = config.updateConfig(updates);
  const { password, ...safe } = updated;
  return res.json({ success: true, config: safe });
});

// ----- File routes -----
const filesRouter = require('./files')(requireAuth);
app.use('/api/files', filesRouter);

// ----- SSH routes -----
const sshRouter = require('./ssh')(requireAuth);
app.use('/api/ssh', sshRouter);

// ----- tmux session routes -----
app.get('/api/sessions', requireAuth, async (req, res) => {
  try {
    const sessions = await tmux.listSessions();
    return res.json({ sessions });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.post('/api/sessions', requireAuth, async (req, res) => {
  try {
    let name = (req.body && typeof req.body.name === 'string') ? req.body.name.trim() : '';
    if (name) {
      if (!/^[A-Za-z0-9_-]{1,64}$/.test(name)) {
        return res.status(400).json({ error: 'Invalid session name (allowed: A-Z a-z 0-9 _ -)' });
      }
      if (await tmux.sessionExists(name)) {
        return res.status(409).json({ error: 'Session "' + name + '" already exists' });
      }
    } else {
      let i = 2;
      while (await tmux.sessionExists('tab-' + i)) i++;
      name = 'tab-' + i;
    }
    await tmux.ensureSession(name, { shell: config.getConfig().shell });
    return res.json({ success: true, name });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.post('/api/sessions/:name/kill', requireAuth, async (req, res) => {
  try { await tmux.killSession(req.params.name); return res.json({ success: true }); }
  catch (err) { return res.status(500).json({ error: err.message }); }
});

// ----- Static frontend -----
app.use(express.static(FRONTEND_DIR, { index: 'index.html' }));
app.get(/^(?!api).*/, (req, res) => {
  const indexPath = path.join(FRONTEND_DIR, 'index.html');
  if (fs.existsSync(indexPath)) return res.sendFile(indexPath);
  res.type('text/html').send('<!doctype html><title>Web Terminal</title><h1>Running</h1>');
});

// ----- HTTP + WebSocket server -----
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true, perMessageDeflate: false });

server.on('upgrade', (req, socket, head) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname || '';
  if (pathname === '/ws' || pathname === '/ws/ssh') {
    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit('connection', ws, req, pathname);
    });
  } else {
    socket.destroy();
  }
});

function wsAuthFromRequest(req) {
  try {
    const parsed = url.parse(req.url, true);
    if (parsed.query && parsed.query.token) {
      return auth.verifyToken(parsed.query.token);
    }
  } catch {}
  const cookieHeader = req.headers.cookie || '';
  const cookies = Object.fromEntries(
    cookieHeader.split(';').map(c => c.trim()).filter(Boolean).map(c => {
      const idx = c.indexOf('=');
      return idx === -1 ? [c, ''] : [c.slice(0, idx), decodeURIComponent(c.slice(idx + 1))];
    })
  );
  if (cookies.token) return auth.verifyToken(cookies.token);
  return null;
}

wss.on('connection', (ws, req, pathname) => {
  if (pathname === '/ws/ssh') {
    handleSSH(ws, req);
  } else {
    handleTerminal(ws, req);
  }
});

function handleTerminal(ws, req) {
  const user = wsAuthFromRequest(req);
  if (!user) { ws.close(1008, 'Unauthorized'); return; }

  // Per-tab session support: /ws?session=<name> attaches to a specific tmux
  // session so each browser tab can hold an independent terminal.
  const parsedUrl = url.parse(req.url, true);
  let sessionName = (parsedUrl.query && typeof parsedUrl.query.session === 'string')
    ? parsedUrl.query.session
    : SESSION_NAME;
  if (!/^[A-Za-z0-9_-]{1,64}$/.test(sessionName)) {
    ws.close(1008, 'Bad session name');
    return;
  }

  let ptyProc = null;
  let alive = true;

  (async () => {
    try {
      await tmux.ensureSession(sessionName, { shell: config.getConfig().shell });
      ptyProc = await tmux.attachSession(sessionName, { cols: 80, rows: 24 });
    } catch (err) {
      try { ws.send(JSON.stringify({ type: 'error', message: err.message })); } catch {}
      ws.close(1011);
      return;
    }

    ptyProc.onData((data) => {
      if (alive && ws.readyState === ws.OPEN) {
        try { ws.send(JSON.stringify({ type: 'data', data: data.toString('utf8') })); } catch {}
      }
    });

    ptyProc.onExit(() => {
      if (alive && ws.readyState === ws.OPEN) {
        try { ws.send(JSON.stringify({ type: 'exit' })); } catch {}
        ws.close(1000);
      }
      alive = false;
    });

    try { ws.send(JSON.stringify({ type: 'ready', session: sessionName })); } catch {}
  })();

  ws.on('message', (raw) => {
    if (!ptyProc) return;
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { ptyProc.write(raw.toString()); return; }
    if (msg.type === 'data') ptyProc.write(msg.data);
    else if (msg.type === 'resize') { try { ptyProc.resize(msg.cols, msg.rows); } catch {} }
  });

  ws.on('close', () => { alive = false; if (ptyProc) try { ptyProc.kill(); } catch {} });
  ws.on('error', () => { alive = false; if (ptyProc) try { ptyProc.kill(); } catch {} });
}

function handleSSH(ws, req) {
  const user = wsAuthFromRequest(req);
  if (!user) { ws.close(1008, 'Unauthorized'); return; }

  const parsed = url.parse(req.url, true);
  const connectionId = parsed.query && parsed.query.connectionId;
  if (!connectionId) { ws.close(1008); return; }

  const { Client } = require('ssh2');
  const connInfo = (config.getConfig().sshConnections || []).find(c => String(c.id) === String(connectionId));
  if (!connInfo) { ws.close(1008); return; }

  const sshConn = new Client();
  let sshStream = null;
  let alive = true;

  sshConn.on('ready', () => {
    sshConn.shell({ term: 'xterm-256color', cols: 80, rows: 24 }, (err, stream) => {
      if (err) { ws.close(1011); return; }
      sshStream = stream;
      stream.on('data', d => { if (alive && ws.readyState === ws.OPEN) try { ws.send(JSON.stringify({type:'data',data:d.toString('utf8')})); } catch {} });
      stream.stderr.on('data', d => { if (alive && ws.readyState === ws.OPEN) try { ws.send(JSON.stringify({type:'data',data:d.toString('utf8')})); } catch {} });
      stream.on('close', () => { if (alive && ws.readyState === ws.OPEN) { try{ws.send(JSON.stringify({type:'exit'}));}catch{} ws.close(1000); } alive = false; });
      try { ws.send(JSON.stringify({ type: 'ready' })); } catch {}
    });
  });

  sshConn.on('error', () => { if (alive && ws.readyState === ws.OPEN) ws.close(1011); alive = false; });

  sshConn.connect({
    host: connInfo.host, port: connInfo.port || 22, username: connInfo.username,
    password: connInfo.password || undefined, privateKey: connInfo.privateKey || undefined,
  });

  ws.on('message', (raw) => {
    if (!sshStream) return;
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { sshStream.write(raw.toString()); return; }
    if (msg.type === 'data') sshStream.write(msg.data);
    else if (msg.type === 'resize') { try { sshStream.setWindow(msg.rows, msg.cols, 480, 640); } catch {} }
  });

  ws.on('close', () => { alive = false; try { sshConn.end(); } catch {} });
  ws.on('error', () => { alive = false; try { sshConn.end(); } catch {} });
}

// ----- Error handler -----
app.use((err, req, res, next) => {
  console.error('[server] error:', err.message);
  res.status(500).json({ error: 'Internal server error' });
});

server.listen(PORT, () => {
  console.log(`[web-terminal] listening on http://0.0.0.0:${PORT}`);
  console.log(`[web-terminal] tmux session: "${SESSION_NAME}" | frontend: ${FRONTEND_DIR}`);
});

function shutdown(signal) {
  console.log(`[web-terminal] ${signal} received, shutting down...`);
  wss.clients.forEach(c => { try { c.close(1001); } catch {} });
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));