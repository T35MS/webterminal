// config.js - Configuration manager for the web terminal.
//
// Reads/writes /home/ubuntu/web-terminal/config/config.json and caches the
// parsed object in memory. The password field is stored as plaintext in the
// config file (per the app's initial design); auth.js handles bcrypt hashing
// and verification at runtime.

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', 'config', 'config.json');

// In-memory cache so callers don't hit disk on every read.
let configCache = null;

// Default config used if the file is missing or unreadable.
const DEFAULT_CONFIG = {
  password: 'Memekenak123',
  port: 3000,
  sessionName: 'main',
  shell: '/bin/bash',
  theme: 'dark',
  fontSize: 14,
  fontFamily: "'Fira Code', 'Cascadia Code', monospace",
  sshConnections: []
};

function loadFromDisk() {
  try {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.warn(`[config] Could not read ${CONFIG_PATH}: ${err.message}. Using defaults.`);
    return { ...DEFAULT_CONFIG };
  }
}

function saveToDisk(cfg) {
  const dir = path.dirname(CONFIG_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2) + '\n', 'utf8');
}

// Returns the current config, loading from disk on first call.
function getConfig() {
  if (configCache === null) {
    configCache = loadFromDisk();
    // Backfill any missing keys with defaults so callers always see complete
    // config even if the on-disk file is partial.
    configCache = { ...DEFAULT_CONFIG, ...configCache };
  }
  return configCache;
}

// Merges a partial update into the config and persists to disk.
function updateConfig(partial) {
  const current = getConfig();
  configCache = { ...current, ...partial };
  saveToDisk(configCache);
  return configCache;
}

// Replace the password in config (used by auth.changePassword).
function setPassword(newPassword) {
  const current = getConfig();
  configCache = { ...current, password: newPassword };
  saveToDisk(configCache);
  return configCache;
}

// Force a reload from disk (useful for tests or external edits).
function reload() {
  configCache = null;
  return getConfig();
}

module.exports = {
  CONFIG_PATH,
  getConfig,
  updateConfig,
  setPassword,
  reload
};