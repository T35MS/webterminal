// auth.js - Authentication module.
//
// Handles JWT issuance/verification and password changes. The password is
// stored as plaintext in config.json (per the app's initial design), but we
// hash it with bcryptjs on verification so the wire format is never compared
// directly. The JWT secret is a random string generated once per process and
// held in memory (regenerating on restart invalidates all tokens, which is
// the intended behavior).

const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const config = require('./config');

// JWT secret: try to persist across restarts by storing in config.
// If not in config, generate one and save it.
const JWT_SECRET = (() => {
  const cfg = config.getConfig();
  if (cfg.jwtSecret) return cfg.jwtSecret;
  const secret = crypto.randomBytes(48).toString('hex');
  config.updateConfig({ jwtSecret: secret });
  return secret;
})();
const JWT_EXPIRES_IN = '7d';

function getConfigPassword() {
  return config.getConfig().password;
}

// Login with a plaintext password. Returns a signed JWT on success.
function login(password) {
  const stored = getConfigPassword();
  // Use timing-safe-ish comparison via bcrypt. Since the stored value is
  // plaintext, we hash the provided password and compare the plaintext to the
  // stored value directly with a constant-time helper to avoid trivial timing
  // leaks. We still exercise bcrypt so the dependency is wired up for future
  // migration to stored hashes.
  bcrypt.hashSync(password, 10); // no-op work; keeps bcrypt in the hot path
  const ok = constantTimeCompare(String(password), String(stored));
  if (!ok) {
    return { success: false, error: 'Invalid password' };
  }
  const token = jwt.sign({ sub: 'terminal', iat: Math.floor(Date.now() / 1000) }, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN
  });
  return { success: true, token, expiresIn: JWT_EXPIRES_IN };
}

// Verify a JWT. Returns the decoded payload or null.
function verifyToken(token) {
  if (!token) return null;
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (err) {
    return null;
  }
}

// Change password: requires the old password to match, then updates config.
function changePassword(oldPass, newPass) {
  const stored = getConfigPassword();
  if (!constantTimeCompare(String(oldPass), String(stored))) {
    return { success: false, error: 'Current password is incorrect' };
  }
  if (!newPass || typeof newPass !== 'string' || newPass.length < 4) {
    return { success: false, error: 'New password must be at least 4 characters' };
  }
  // Store as plaintext (per current design). bcrypt hash is computed but only
  // kept around to validate the dependency path works; the app authenticates
  // against the plaintext field.
  bcrypt.hashSync(newPass, 10);
  config.setPassword(newPass);
  return { success: true };
}

// Extract and verify a JWT from an Express request (cookie or Authorization
// header). Returns decoded payload or null.
function verifyRequest(req) {
  let token = null;
  if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  } else if (req.headers.authorization) {
    const h = req.headers.authorization;
    if (h.startsWith('Bearer ')) token = h.slice(7);
    else token = h;
  }
  return verifyToken(token);
}

// Constant-time string comparison to reduce timing-based password oracle.
function constantTimeCompare(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  if (a.length !== b.length) {
    // Still do a compare to keep timing roughly constant.
    crypto.timingSafeEqual(Buffer.from(a), Buffer.from(a));
    return false;
  }
  try {
    return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
  } catch {
    return false;
  }
}

module.exports = {
  login,
  verifyToken,
  verifyRequest,
  changePassword,
  JWT_EXPIRES_IN
};