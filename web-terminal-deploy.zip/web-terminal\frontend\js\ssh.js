/* ==========================================================================
   Web Terminal — SSH Manager Logic
   ========================================================================== */

(function () {
  'use strict';

  /* ---------- Auth ---------- */
  function getToken() {
    var token = localStorage.getItem('wt_token');
    if (!token) {
      window.location.href = '/';
      return null;
    }
    return token;
  }

  function apiFetch(path, opts) {
    opts = opts || {};
    opts.headers = opts.headers || {};
    opts.headers['Authorization'] = 'Bearer ' + getToken();
    return fetch(path, opts);
  }

  function handleAuthError(res) {
    if (res.status === 401 || res.status === 403) {
      localStorage.removeItem('wt_token');
      window.location.href = '/';
      return true;
    }
    return false;
  }

  /* ---------- State ---------- */
  var connections = [];
  var selectedConnection = null;
  var currentPath = '/';
  var editingConnId = null;

  // Terminal state
  var term = null;
  var fitAddon = null;
  var shellSocket = null;
  var shellConnected = false;

  // File manager state
  var remoteEditor = null;
  var monacoReady = false;
  var currentEditingPath = null;

  // Quick command history
  var cmdHistory = [];
  var cmdHistoryIndex = -1;

  /* ---------- DOM References ---------- */
  var connListEl = document.getElementById('connList');
  var addConnBtn = document.getElementById('addConnBtn');
  var logoutBtn = document.getElementById('logoutBtn');
  var toastContainer = document.getElementById('toastContainer');
  var remoteTabs = document.getElementById('remoteTabs');

  // Shell panel
  var shellStatusLabel = document.getElementById('shellStatusLabel');
  var shellConnectBtn = document.getElementById('shellConnectBtn');
  var shellDisconnectBtn = document.getElementById('shellDisconnectBtn');
  var remoteTerminal = document.getElementById('remoteTerminal');

  // Files panel
  var remoteBreadcrumb = document.getElementById('remoteBreadcrumb');
  var remoteFilesEl = document.getElementById('remoteFiles');
  var remoteRefreshBtn = document.getElementById('remoteRefreshBtn');
  var remoteUploadBtn = document.getElementById('remoteUploadBtn');
  var remoteSaveBtn = document.getElementById('remoteSaveBtn');
  var remoteCloseEditorBtn = document.getElementById('remoteCloseEditorBtn');
  var remoteEditorWrap = document.getElementById('remoteEditorWrap');
  var uploadFileInput = document.getElementById('uploadFileInput');

  // Quick cmd panel
  var quickCmdInput = document.getElementById('quickCmdInput');
  var quickCmdExecBtn = document.getElementById('quickCmdExecBtn');
  var quickCmdOutput = document.getElementById('quickCmdOutput');

  // Modal
  var connModal = document.getElementById('connModal');
  var connModalTitle = document.getElementById('connModalTitle');
  var connModalClose = document.getElementById('connModalClose');
  var connIdField = document.getElementById('connIdField');
  var connName = document.getElementById('connName');
  var connHost = document.getElementById('connHost');
  var connPort = document.getElementById('connPort');
  var connUser = document.getElementById('connUser');
  var connPassword = document.getElementById('connPassword');
  var connKey = document.getElementById('connKey');
  var connFormMsg = document.getElementById('connFormMsg');
  var connTestBtn = document.getElementById('connTestBtn');
  var connCancelBtn = document.getElementById('connCancelBtn');
  var connSaveBtn = document.getElementById('connSaveBtn');

  // Context menu
  var ctxMenu = document.getElementById('ctxMenu');

  /* ---------- Toast ---------- */
  function toast(msg, type) {
    var el = document.createElement('div');
    el.className = 'toast ' + (type || 'info');
    el.textContent = msg;
    toastContainer.appendChild(el);
    setTimeout(function () {
      el.classList.add('fade-out');
      setTimeout(function () { el.remove(); }, 300);
    }, 3500);
  }

  /* ---------- Utility ---------- */
  function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function getExt(name) {
    var lower = name.toLowerCase();
    var idx = lower.lastIndexOf('.');
    return idx >= 0 ? lower.substring(idx) : '';
  }

  var LANG_MAP = {
    '.js': 'javascript', '.mjs': 'javascript', '.jsx': 'javascript',
    '.ts': 'typescript', '.tsx': 'typescript',
    '.py': 'python',
    '.html': 'html', '.htm': 'html',
    '.css': 'css', '.scss': 'scss', '.less': 'less',
    '.json': 'json',
    '.md': 'markdown', '.markdown': 'markdown',
    '.sh': 'shell', '.bash': 'shell',
    '.go': 'go',
    '.rs': 'rust',
    '.java': 'java',
    '.c': 'c', '.h': 'c',
    '.cpp': 'cpp', '.cc': 'cpp', '.cxx': 'cpp', '.hpp': 'cpp',
    '.sql': 'sql',
    '.xml': 'xml', '.svg': 'xml',
    '.yaml': 'yaml', '.yml': 'yaml',
    '.php': 'php',
    '.rb': 'ruby',
    '.txt': 'plaintext', '.log': 'plaintext'
  };

  function getLanguage(path) {
    var name = path.split('/').pop();
    return LANG_MAP[getExt(name)] || 'plaintext';
  }

  function formatSize(bytes) {
    if (bytes === 0) return '0 B';
    var units = ['B', 'KB', 'MB', 'GB'];
    var i = Math.floor(Math.log(bytes) / Math.log(1024));
    return parseFloat((bytes / Math.pow(1024, i)).toFixed(1)) + ' ' + units[i];
  }

  function joinPath(base, name) {
    if (base === '' || base === '/') return '/' + name;
    return base.replace(/\/$/, '') + '/' + name;
  }

  function dirName(path) {
    var parts = path.replace(/\/$/, '').split('/');
    parts.pop();
    return parts.join('/') || '/';
  }

  function baseName(path) {
    var parts = path.replace(/\/$/, '').split('/');
    return parts[parts.length - 1] || '/';
  }

  /* ---------- Tab Switching ---------- */
  function switchTab(tabName) {
    var tabs = remoteTabs.querySelectorAll('.remote-tab');
    tabs.forEach(function (t) {
      t.classList.toggle('active', t.dataset.tab === tabName);
    });

    var panels = document.querySelectorAll('.remote-tab-panel');
    panels.forEach(function (p) { p.classList.add('hidden'); });

    var panelMap = { shell: 'remoteShellPanel', files: 'remoteFilesPanel', quickcmd: 'quickCmdPanel' };
    var panelId = panelMap[tabName];
    if (panelId) {
      document.getElementById(panelId).classList.remove('hidden');
    }

    // Fit terminal when switching to shell
    if (tabName === 'shell' && term && fitAddon) {
      setTimeout(function () { try { fitAddon.fit(); } catch (e) {} }, 50);
    }
    // Layout editor when switching to files
    if (tabName === 'files' && remoteEditor) {
      setTimeout(function () { remoteEditor.layout(); }, 50);
    }
  }

  remoteTabs.addEventListener('click', function (e) {
    var tab = e.target.closest('.remote-tab');
    if (tab && tab.dataset.tab) {
      switchTab(tab.dataset.tab);
    }
  });

  /* ==========================================================
     CONNECTION MANAGEMENT
     ========================================================== */

  function loadConnections() {
    apiFetch('/api/ssh/connections')
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json();
      })
      .then(function (data) {
        if (data === null) return;
        connections = (data && data.connections) ? data.connections : (Array.isArray(data) ? data : []);
        renderConnections();
      })
      .catch(function (err) {
        toast('Failed to load connections: ' + err.message, 'error');
      });
  }

  function renderConnections() {
    connListEl.innerHTML = '';
    if (connections.length === 0) {
      var empty = document.createElement('div');
      empty.className = 'conn-empty';
      empty.textContent = 'No saved connections. Click + to add one.';
      connListEl.appendChild(empty);
      return;
    }

    connections.forEach(function (conn) {
      var item = document.createElement('div');
      item.className = 'conn-item';
      if (selectedConnection && conn.id === selectedConnection.id) item.classList.add('selected');

      var isConn = (selectedConnection && conn.id === selectedConnection.id && shellConnected);

      item.innerHTML =
        '<div class="conn-row1">' +
          '<span class="status-dot ' + (isConn ? 'connected' : 'disconnected') + '"></span>' +
          '<span class="conn-name">' + escapeHtml(conn.name) + '</span>' +
        '</div>' +
        '<div class="conn-host">' + escapeHtml(conn.host) + ':' + escapeHtml(String(conn.port || 22)) + '</div>' +
        '<div class="conn-user">' + escapeHtml(conn.username) + '</div>';

      // Left click selects
      item.addEventListener('click', function () {
        selectConnection(conn);
      });

      // Right click context menu
      item.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        selectConnection(conn);
        showConnContextMenu(e.clientX, e.clientY, conn);
      });

      connListEl.appendChild(item);
    });
  }

  function selectConnection(conn) {
    selectedConnection = conn;

    // Enable pane buttons
    shellConnectBtn.disabled = false;
    remoteRefreshBtn.disabled = false;
    remoteUploadBtn.disabled = false;
    quickCmdInput.disabled = false;
    quickCmdExecBtn.disabled = false;

    shellStatusLabel.textContent = conn.name + ' — ' + conn.host;

    // Re-render to update selected highlight
    renderConnections();

    // If files tab is active and we have a connection, load files
    if (!document.getElementById('remoteFilesPanel').classList.contains('hidden')) {
      loadRemoteFiles('/');
    }
  }

  /* ---------- Context Menu ---------- */
  function showConnContextMenu(x, y, conn) {
    var items = [
      { label: 'Connect Shell', action: function () { switchTab('shell'); connectShell(conn.id); } },
      { label: 'Browse Files', action: function () { switchTab('files'); selectConnection(conn); loadRemoteFiles('/'); } },
      { sep: true },
      { label: 'Edit', action: function () { openEditModal(conn); } },
      { label: 'Delete', danger: true, action: function () { deleteConnection(conn); } }
    ];
    buildContextMenu(items, x, y);
  }

  function showFileContextMenu(x, y, item, fullPath) {
    var isDir = item.isDir;
    var items = [
      { label: 'New File', action: function () { promptNewRemoteFile(); } },
      { label: 'New Folder', action: function () { promptNewRemoteDir(); } },
      { sep: true }
    ];
    if (!isDir) {
      items.push({ label: 'Open', action: function () { openRemoteFile(fullPath); } });
      items.push({ label: 'Download', action: function () { downloadRemoteFile(fullPath); } });
    }
    items.push({ sep: true });
    items.push({ label: 'Rename', action: function () { promptRenameRemote(item, fullPath); } });
    items.push({ label: 'Delete', danger: true, action: function () { deleteRemoteFile(item, fullPath); } });

    buildContextMenu(items, x, y);
  }

  function buildContextMenu(items, x, y) {
    hideContextMenu();
    ctxMenu.innerHTML = '';
    items.forEach(function (item) {
      if (item.sep) {
        var sep = document.createElement('div');
        sep.className = 'ctx-menu-separator';
        ctxMenu.appendChild(sep);
        return;
      }
      var el = document.createElement('div');
      el.className = 'ctx-menu-item' + (item.danger ? ' danger' : '');
      el.textContent = item.label;
      el.addEventListener('click', function () {
        hideContextMenu();
        item.action();
      });
      ctxMenu.appendChild(el);
    });

    ctxMenu.style.left = x + 'px';
    ctxMenu.style.top = y + 'px';
    ctxMenu.classList.remove('hidden');

    // Adjust if off-screen
    var rect = ctxMenu.getBoundingClientRect();
    if (rect.right > window.innerWidth) {
      ctxMenu.style.left = (window.innerWidth - rect.width - 4) + 'px';
    }
    if (rect.bottom > window.innerHeight) {
      ctxMenu.style.top = (window.innerHeight - rect.height - 4) + 'px';
    }
  }

  function hideContextMenu() {
    ctxMenu.classList.add('hidden');
    ctxMenu.innerHTML = '';
  }

  document.addEventListener('click', function () { hideContextMenu(); });
  document.addEventListener('contextmenu', function (e) {
    if (!e.target.closest('.conn-item') && !e.target.closest('.remote-file-item')) {
      hideContextMenu();
    }
  });

  /* ---------- Modal: Add / Edit ---------- */
  function openAddModal() {
    editingConnId = null;
    connModalTitle.textContent = 'Add SSH Connection';
    connIdField.value = '';
    connName.value = '';
    connHost.value = '';
    connPort.value = '22';
    connUser.value = '';
    connPassword.value = '';
    connKey.value = '';
    connFormMsg.classList.add('hidden');
    connFormMsg.className = 'form-msg hidden';
    connModal.classList.remove('hidden');
    connName.focus();
  }

  function openEditModal(conn) {
    editingConnId = conn.id;
    connModalTitle.textContent = 'Edit SSH Connection';
    connIdField.value = conn.id;
    connName.value = conn.name || '';
    connHost.value = conn.host || '';
    connPort.value = conn.port || 22;
    connUser.value = conn.username || '';
    connPassword.value = ''; // Don't prefill password
    connKey.value = '';      // Don't prefill key
    connFormMsg.classList.add('hidden');
    connFormMsg.className = 'form-msg hidden';
    connModal.classList.remove('hidden');
    connName.focus();
  }

  function closeModal() {
    connModal.classList.add('hidden');
  }

  addConnBtn.addEventListener('click', openAddModal);
  connModalClose.addEventListener('click', closeModal);
  connCancelBtn.addEventListener('click', closeModal);
  connModal.addEventListener('click', function (e) {
    if (e.target === connModal) closeModal();
  });

  function getFormData() {
    return {
      name: connName.value.trim(),
      host: connHost.value.trim(),
      port: parseInt(connPort.value, 10) || 22,
      username: connUser.value.trim(),
      password: connPassword.value || undefined,
      privateKey: connKey.value || undefined
    };
  }

  function validateForm(data) {
    if (!data.name) return 'Name is required';
    if (!data.host) return 'Host is required';
    if (!data.username) return 'Username is required';
    return null;
  }

  function showFormMsg(msg, type) {
    connFormMsg.textContent = msg;
    connFormMsg.className = 'form-msg ' + (type || 'error');
    connFormMsg.classList.remove('hidden');
  }

  /* ---------- Save ---------- */
  connSaveBtn.addEventListener('click', function () {
    var data = getFormData();
    var err = validateForm(data);
    if (err) {
      showFormMsg(err, 'error');
      return;
    }

    connSaveBtn.disabled = true;
    var url, method;
    if (editingConnId) {
      url = '/api/ssh/connections/' + encodeURIComponent(editingConnId);
      method = 'PUT';
    } else {
      url = '/api/ssh/connections';
      method = 'POST';
    }

    apiFetch(url, {
      method: method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json().then(function (body) {
          return { status: res.status, body: body };
        });
      })
      .then(function (result) {
        if (result === null) return;
        connSaveBtn.disabled = false;
        if (result.status >= 200 && result.status < 300) {
          toast(editingConnId ? 'Connection updated' : 'Connection added', 'success');
          closeModal();
          loadConnections();
        } else {
          showFormMsg((result.body && result.body.error) || 'Failed to save', 'error');
        }
      })
      .catch(function (err) {
        connSaveBtn.disabled = false;
        showFormMsg('Error: ' + err.message, 'error');
      });
  });

  /* ---------- Test ---------- */
  connTestBtn.addEventListener('click', function () {
    var data = getFormData();
    var err = validateForm(data);
    if (err) {
      showFormMsg(err, 'error');
      return;
    }

    connTestBtn.disabled = true;
    connTestBtn.textContent = 'Testing…';
    showFormMsg('Testing connection…', 'success');

    apiFetch('/api/ssh/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json().then(function (body) {
          return { status: res.status, body: body };
        });
      })
      .then(function (result) {
        if (result === null) return;
        connTestBtn.disabled = false;
        connTestBtn.textContent = 'Test Connection';
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
          showFormMsg('✓ Connection successful!', 'success');
          toast('Connection test succeeded', 'success');
        } else {
          showFormMsg((result.body && (result.body.error || result.body.message)) || 'Connection failed', 'error');
          toast('Connection test failed', 'error');
        }
      })
      .catch(function (err) {
        connTestBtn.disabled = false;
        connTestBtn.textContent = 'Test Connection';
        showFormMsg('Error: ' + err.message, 'error');
      });
  });

  /* ---------- Delete ---------- */
  function deleteConnection(conn) {
    if (!confirm('Delete connection "' + conn.name + '"?')) return;
    apiFetch('/api/ssh/connections/' + encodeURIComponent(conn.id), {
      method: 'DELETE'
    })
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json();
      })
      .then(function (data) {
        if (data === null) return;
        toast('Connection deleted', 'success');
        if (selectedConnection && selectedConnection.id === conn.id) {
          if (shellConnected) disconnectShell();
          selectedConnection = null;
          shellConnectBtn.disabled = true;
          remoteRefreshBtn.disabled = true;
          remoteUploadBtn.disabled = true;
          remoteSaveBtn.disabled = true;
          quickCmdInput.disabled = true;
          quickCmdExecBtn.disabled = true;
          shellStatusLabel.textContent = 'No connection selected';
          remoteFilesEl.innerHTML = '';
          remoteBreadcrumb.innerHTML = '';
        }
        loadConnections();
      })
      .catch(function (err) {
        toast('Delete failed: ' + err.message, 'error');
      });
  }

  /* ==========================================================
     REMOTE TERMINAL (SSH Shell via WebSocket + xterm.js)
     ========================================================== */

  function initTerminal() {
    if (term) return;
    term = new Terminal({
      cursorBlink: true,
      fontSize: 14,
      fontFamily: "'Fira Code', 'JetBrains Mono', 'Source Code Pro', monospace",
      theme: {
        background: '#0d1117',
        foreground: '#e6edf3',
        cursor: '#58a6ff',
        selectionBackground: '#264f78'
      },
      allowProposedApi: true
    });
    fitAddon = new FitAddon.FitAddon();
    term.loadAddon(fitAddon);
    try { term.loadAddon(new WebLinksAddon.WebLinksAddon()); } catch (e) {}

    term.open(remoteTerminal);
    try { fitAddon.fit(); } catch (e) {}

    // Send user input to WebSocket as {type:'data',data:'...'}
    term.onData(function (data) {
      if (shellSocket && shellSocket.readyState === WebSocket.OPEN) {
        shellSocket.send(JSON.stringify({ type: 'data', data: data }));
      }
    });

    // Handle resize -> {type:'resize',cols,rows}
    term.onResize(function (size) {
      if (shellSocket && shellSocket.readyState === WebSocket.OPEN) {
        shellSocket.send(JSON.stringify({ type: 'resize', cols: size.cols, rows: size.rows }));
      }
    });

    // Window resize
    window.addEventListener('resize', function () {
      if (fitAddon) {
        try { fitAddon.fit(); } catch (e) {}
      }
    });
  }

  function connectShell(connectionId) {
    var token = getToken();
    if (!token) return;

    if (shellConnected) {
      disconnectShell();
    }

    var conn = connections.find(function (c) { return c.id === connectionId; });
    if (!conn) {
      toast('Connection not found', 'error');
      return;
    }

    initTerminal();

    shellConnectBtn.disabled = true;
    shellStatusLabel.textContent = conn.name + ' — Connecting…';
    term.writeln('\x1b[33mConnecting to ' + conn.host + '...\x1b[0m');

    var proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    var url = proto + '//' + location.host + '/ws/ssh?token=' + encodeURIComponent(token) +
              '&connectionId=' + encodeURIComponent(connectionId);

    try {
      shellSocket = new WebSocket(url);
    } catch (e) {
      term.writeln('\x1b[31mFailed to create WebSocket: ' + e.message + '\x1b[0m');
      shellConnectBtn.disabled = false;
      shellStatusLabel.textContent = conn.name + ' — Connection failed';
      return;
    }

    shellSocket.binaryType = 'arraybuffer';

    shellSocket.onopen = function () {
      shellConnected = true;
      shellDisconnectBtn.disabled = false;
      shellConnectBtn.disabled = false;
      shellConnectBtn.textContent = 'Reconnect';
      shellStatusLabel.textContent = conn.name + ' — Connected';
      term.writeln('\x1b[32mConnected.\x1b[0m');
      // Send initial terminal size
      shellSocket.send(JSON.stringify({ type: 'resize', cols: term.cols, rows: term.rows }));
      try { fitAddon.fit(); } catch (e) {}
      renderConnections();
    };

    shellSocket.onmessage = function (event) {
      var raw = event.data;
      if (typeof raw === 'string') {
        // Try JSON first; fall back to raw
        try {
          var msg = JSON.parse(raw);
          if (msg) {
            if (msg.type === 'data' && typeof msg.data === 'string') {
              term.write(msg.data);
            } else if (msg.type === 'error') {
              term.writeln('\x1b[31m' + (msg.message || 'Error') + '\x1b[0m');
            } else if (msg.type === 'ready') {
              shellConnected = true;
              shellStatusLabel.textContent = conn.name + ' — Connected';
            }
          }
        } catch (_) {
          term.write(raw);
        }
      } else if (raw instanceof ArrayBuffer) {
        term.write(new TextDecoder('utf-8').decode(new Uint8Array(raw)));
      }
    };

    shellSocket.onerror = function () {
      term.writeln('\x1b[31mWebSocket error.\x1b[0m');
    };

    shellSocket.onclose = function () {
      shellConnected = false;
      shellSocket = null;
      shellDisconnectBtn.disabled = true;
      shellConnectBtn.disabled = false;
      shellConnectBtn.textContent = 'Connect Shell';
      shellStatusLabel.textContent = conn.name + ' — Disconnected';
      term.writeln('\x1b[33mConnection closed.\x1b[0m');
      renderConnections();
    };
  }

  function disconnectShell() {
    if (shellSocket) {
      try { shellSocket.close(); } catch (e) {}
      shellSocket = null;
    }
    shellConnected = false;
    shellDisconnectBtn.disabled = true;
    shellConnectBtn.disabled = false;
    shellConnectBtn.textContent = 'Connect Shell';

    var conn = selectedConnection;
    shellStatusLabel.textContent = conn ? (conn.name + ' — Disconnected') : 'No connection selected';
    renderConnections();
  }

  shellConnectBtn.addEventListener('click', function () {
    if (selectedConnection) connectShell(selectedConnection.id);
  });

  shellDisconnectBtn.addEventListener('click', disconnectShell);

  /* ==========================================================
     REMOTE FILE MANAGER
     ========================================================== */

  function loadRemoteFiles(path) {
    if (!selectedConnection) return;
    currentPath = path || '/';

    apiFetch('/api/ssh/files?connectionId=' + encodeURIComponent(selectedConnection.id) +
             '&path=' + encodeURIComponent(currentPath))
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json();
      })
      .then(function (data) {
        if (data === null) return;
        renderRemoteBreadcrumb(currentPath);
        renderRemoteFiles(data.files || data || []);
      })
      .catch(function (err) {
        toast('Failed to list files: ' + err.message, 'error');
        remoteFilesEl.innerHTML = '<div class="remote-files-empty">Error: ' + escapeHtml(err.message) + '</div>';
      });
  }

  function renderRemoteBreadcrumb(path) {
    remoteBreadcrumb.innerHTML = '';
    var parts = path.replace(/^\/+/, '').split('/').filter(Boolean);

    var root = document.createElement('span');
    root.className = 'crumb';
    root.textContent = '/';
    root.addEventListener('click', function () { loadRemoteFiles('/'); });
    remoteBreadcrumb.appendChild(root);

    var accum = '';
    parts.forEach(function (part) {
      accum += '/' + part;
      var sep = document.createElement('span');
      sep.className = 'sep';
      sep.textContent = '›';
      remoteBreadcrumb.appendChild(sep);

      var item = document.createElement('span');
      item.className = 'crumb';
      item.textContent = part;
      (function (p) {
        item.addEventListener('click', function () { loadRemoteFiles(p); });
      })(accum);
      remoteBreadcrumb.appendChild(item);
    });
  }

  function renderRemoteFiles(items) {
    remoteFilesEl.innerHTML = '';
    if (!items || items.length === 0) {
      remoteFilesEl.innerHTML = '<div class="remote-files-empty">This directory is empty.</div>';
      return;
    }

    // Sort: folders first, then by name
    items.sort(function (a, b) {
      if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
      return (a.name || '').localeCompare(b.name || '');
    });

    items.forEach(function (item) {
      var el = document.createElement('div');
      el.className = 'remote-file-item';

      var iconSvg = item.isDir
        ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>'
        : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>';

      var sizeStr = (!item.isDir && item.size != null) ? formatSize(item.size) : '';
      var dateStr = item.modified ? new Date(item.modified).toLocaleDateString() : '';

      el.innerHTML =
        '<span class="rf-icon ' + (item.isDir ? 'folder' : 'file') + '">' + iconSvg + '</span>' +
        '<span class="rf-name">' + escapeHtml(item.name) + '</span>' +
        (sizeStr ? '<span class="rf-size">' + sizeStr + '</span>' : '') +
        (dateStr ? '<span class="rf-date">' + dateStr + '</span>' : '');

      var fullPath = joinPath(currentPath, item.name);

      el.addEventListener('click', function () {
        if (item.isDir) {
          loadRemoteFiles(fullPath);
        } else {
          openRemoteFile(fullPath);
        }
        // Highlight
        remoteFilesEl.querySelectorAll('.remote-file-item').forEach(function (n) { n.classList.remove('selected'); });
        el.classList.add('selected');
      });

      el.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        showFileContextMenu(e.clientX, e.clientY, item, fullPath);
      });

      remoteFilesEl.appendChild(el);
    });
  }

  /* ---------- Open / Edit Remote File ---------- */
  function openRemoteFile(path) {
    if (!selectedConnection) return;
    initMonaco();

    apiFetch('/api/ssh/files/read?connectionId=' + encodeURIComponent(selectedConnection.id) +
             '&path=' + encodeURIComponent(path))
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json();
      })
      .then(function (data) {
        if (data === null) return;
        if (data.error) {
          toast(data.error, 'error');
          return;
        }
        currentEditingPath = path;
        var content = data.content || '';

        // Show editor in split layout
        remoteFilesEl.classList.add('hidden');
        remoteFilesEl.parentElement.classList.add('split');
        remoteEditorWrap.classList.remove('hidden');
        remoteCloseEditorBtn.hidden = false;
        remoteSaveBtn.disabled = false;

        if (monacoReady && remoteEditor) {
          var model = monaco.editor.createModel(content, getLanguage(path));
          remoteEditor.setModel(model);
          remoteEditor.updateOptions({ readOnly: false });
          setTimeout(function () { remoteEditor.layout(); }, 50);
        } else {
          // Monaco not ready yet, will be set when it initializes
          var check = setInterval(function () {
            if (monacoReady && remoteEditor) {
              clearInterval(check);
              var m = monaco.editor.createModel(content, getLanguage(path));
              remoteEditor.setModel(m);
              remoteEditor.layout();
            }
          }, 100);
        }
      })
      .catch(function (err) {
        toast('Failed to read file: ' + err.message, 'error');
      });
  }

  /* ---------- Save Remote File ---------- */
  remoteSaveBtn.addEventListener('click', function () {
    if (!currentEditingPath || !selectedConnection) return;
    if (!remoteEditor) return;

    var content = remoteEditor.getValue();
    remoteSaveBtn.disabled = true;
    remoteSaveBtn.textContent = 'Saving…';

    apiFetch('/api/ssh/files/write', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        connectionId: selectedConnection.id,
        path: currentEditingPath,
        content: content
      })
    })
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json();
      })
      .then(function (data) {
        if (data === null) return;
        remoteSaveBtn.disabled = false;
        remoteSaveBtn.textContent = 'Save';
        if (data.error) {
          toast(data.error, 'error');
        } else {
          toast('File saved', 'success');
        }
      })
      .catch(function (err) {
        remoteSaveBtn.disabled = false;
        remoteSaveBtn.textContent = 'Save';
        toast('Save failed: ' + err.message, 'error');
      });
  });

  /* ---------- Close editor / back to files ---------- */
  remoteCloseEditorBtn.addEventListener('click', closeRemoteEditor);

  function closeRemoteEditor() {
    remoteEditorWrap.classList.add('hidden');
    remoteFilesEl.classList.remove('hidden');
    remoteFilesEl.parentElement.classList.remove('split');
    remoteCloseEditorBtn.hidden = true;
    remoteSaveBtn.disabled = true;
    currentEditingPath = null;
  }

  /* ---------- New File / Folder ---------- */
  function promptNewRemoteFile() {
    var name = prompt('New file name:');
    if (!name) return;
    var path = joinPath(currentPath, name);
    apiFetch('/api/ssh/files/write', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        connectionId: selectedConnection.id,
        path: path,
        content: ''
      })
    })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (data.error) { toast(data.error, 'error'); return; }
        toast('File created', 'success');
        loadRemoteFiles(currentPath);
      })
      .catch(function (err) { toast('Error: ' + err.message, 'error'); });
  }

  function promptNewRemoteDir() {
    var name = prompt('New folder name:');
    if (!name) return;
    var path = joinPath(currentPath, name);
    apiFetch('/api/ssh/files/mkdir', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        connectionId: selectedConnection.id,
        path: path
      })
    })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (data.error) { toast(data.error, 'error'); return; }
        toast('Folder created', 'success');
        loadRemoteFiles(currentPath);
      })
      .catch(function (err) { toast('Error: ' + err.message, 'error'); });
  }

  /* ---------- Rename ---------- */
  function promptRenameRemote(item, oldPath) {
    var newName = prompt('Rename to:', item.name);
    if (!newName || newName === item.name) return;
    var newPath = joinPath(currentPath, newName);
    apiFetch('/api/ssh/files/rename', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        connectionId: selectedConnection.id,
        oldPath: oldPath,
        newPath: newPath
      })
    })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (data.error) { toast(data.error, 'error'); return; }
        toast('Renamed', 'success');
        loadRemoteFiles(currentPath);
      })
      .catch(function (err) { toast('Error: ' + err.message, 'error'); });
  }

  /* ---------- Delete ---------- */
  function deleteRemoteFile(item, path) {
    if (!confirm('Delete "' + item.name + '"?')) return;
    apiFetch('/api/ssh/files/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        connectionId: selectedConnection.id,
        path: path
      })
    })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (data.error) { toast(data.error, 'error'); return; }
        toast('Deleted', 'success');
        // If editing this file, close editor
        if (currentEditingPath === path) {
          closeRemoteEditor();
        }
        loadRemoteFiles(currentPath);
      })
      .catch(function (err) { toast('Error: ' + err.message, 'error'); });
  }

  /* ---------- Download ---------- */
  function downloadRemoteFile(path) {
    if (!selectedConnection) return;
    var token = getToken();
    if (!token) return;
    // Trigger download via authenticated URL
    var url = '/api/ssh/files/download?connectionId=' + encodeURIComponent(selectedConnection.id) +
              '&path=' + encodeURIComponent(path) +
              '&token=' + encodeURIComponent(token);
    var a = document.createElement('a');
    a.href = url;
    a.download = baseName(path);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  /* ---------- Upload (FormData POST) ---------- */
  remoteUploadBtn.addEventListener('click', function () {
    if (!selectedConnection) return;
    uploadFileInput.click();
  });

  uploadFileInput.addEventListener('change', function () {
    var files = uploadFileInput.files;
    if (!files || files.length === 0) return;
    uploadRemoteFiles(files);
    uploadFileInput.value = '';
  });

  function uploadRemoteFiles(files) {
    var uploaded = 0;
    var total = files.length;
    Array.prototype.forEach.call(files, function (file) {
      var formData = new FormData();
      formData.append('connectionId', selectedConnection.id);
      formData.append('path', joinPath(currentPath, file.name));
      formData.append('file', file);

      apiFetch('/api/ssh/files/upload', {
        method: 'POST',
        body: formData
      })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          uploaded++;
          if (data.error) { toast('Upload ' + file.name + ' failed: ' + data.error, 'error'); }
          else { toast('Uploaded ' + file.name, 'success'); }
          if (uploaded >= total) loadRemoteFiles(currentPath);
        })
        .catch(function (err) {
          uploaded++;
          toast('Upload ' + file.name + ' error: ' + err.message, 'error');
          if (uploaded >= total) loadRemoteFiles(currentPath);
        });
    });
  }

  /* ---------- Refresh ---------- */
  remoteRefreshBtn.addEventListener('click', function () {
    loadRemoteFiles(currentPath || '/');
  });

  /* ==========================================================
     MONACO EDITOR
     ========================================================== */
  function initMonaco() {
    if (monacoReady) return;
    require.config({
      paths: { 'vs': 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs' }
    });

    require(['vs/editor/editor.main'], function () {
      monaco.editor.defineTheme('wt-dark', {
        base: 'vs-dark',
        inherit: true,
        rules: [],
        colors: {
          'editor.background': '#0d1117',
          'editor.foreground': '#e6edf3',
          'editorLineNumber.foreground': '#6e7681',
          'editorLineNumber.activeForeground': '#e6edf3',
          'editor.selectionBackground': '#264f78',
          'editor.lineHighlightBackground': '#161b22',
          'editorCursor.foreground': '#58a6ff',
          'editorIndentGuide.background': '#21262d',
          'editorIndentGuide.activeBackground': '#30363d',
          'editorWidget.background': '#161b22',
          'editorWidget.border': '#30363d',
          'scrollbarSlider.background': '#30363d80',
          'scrollbarSlider.hoverBackground': '#30363d',
          'scrollbarSlider.activeBackground': '#484f58'
        }
      });

      remoteEditor = monaco.editor.create(document.getElementById('remoteEditor'), {
        value: '',
        language: 'plaintext',
        theme: 'wt-dark',
        fontSize: 14,
        fontFamily: "'Fira Code', 'JetBrains Mono', 'Source Code Pro', monospace",
        fontLigatures: true,
        minimap: { enabled: false },
        wordWrap: 'on',
        lineNumbers: 'on',
        automaticLayout: true,
        scrollBeyondLastLine: false,
        smoothScrolling: true,
        cursorBlinking: 'smooth',
        cursorSmoothCaretAnimation: 'on',
        tabSize: 2,
        padding: { top: 8, bottom: 8 }
      });

      monacoReady = true;
    });
  }

  /* ==========================================================
     QUICK COMMAND
     ========================================================== */

  function executeQuickCommand(cmd) {
    if (!cmd.trim()) return;
    if (!selectedConnection) {
      toast('Select a connection first', 'error');
      return;
    }

    // Add to history
    if (cmdHistory.length === 0 || cmdHistory[cmdHistory.length - 1] !== cmd) {
      cmdHistory.push(cmd);
    }
    cmdHistoryIndex = cmdHistory.length;

    // Clear placeholder if present
    var placeholder = quickCmdOutput.querySelector('.cmd-placeholder');
    if (placeholder) placeholder.remove();

    // Render command line
    var lineEl = document.createElement('div');
    lineEl.className = 'cmd-line';
    lineEl.textContent = '$ ' + cmd;
    quickCmdOutput.appendChild(lineEl);

    var stdoutEl = document.createElement('div');
    stdoutEl.className = 'cmd-stdout';
    quickCmdOutput.appendChild(stdoutEl);

    var stderrEl = document.createElement('div');
    stderrEl.className = 'cmd-stderr';
    quickCmdOutput.appendChild(stderrEl);

    var metaEl = document.createElement('div');
    metaEl.className = 'cmd-meta';
    quickCmdOutput.appendChild(metaEl);

    quickCmdExecBtn.disabled = true;
    quickCmdExecBtn.textContent = 'Running…';

    apiFetch('/api/ssh/exec', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        connectionId: selectedConnection.id,
        command: cmd
      })
    })
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json();
      })
      .then(function (data) {
        if (data === null) return;
        if (data.error) {
          stderrEl.textContent = data.error;
        } else {
          if (data.stdout) stdoutEl.textContent = data.stdout;
          if (data.stderr) stderrEl.textContent = data.stderr;
          if (data.exitCode !== undefined) {
            metaEl.textContent = 'Exit code: ' + data.exitCode;
          }
        }
        quickCmdOutput.scrollTop = quickCmdOutput.scrollHeight;
      })
      .catch(function (err) {
        stderrEl.textContent = 'Error: ' + err.message;
      })
      .finally(function () {
        quickCmdExecBtn.disabled = false;
        quickCmdExecBtn.textContent = 'Execute';
      });
  }

  quickCmdExecBtn.addEventListener('click', function () {
    var cmd = quickCmdInput.value;
    executeQuickCommand(cmd);
    quickCmdInput.value = '';
  });

  quickCmdInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      var cmd = quickCmdInput.value;
      executeQuickCommand(cmd);
      quickCmdInput.value = '';
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (cmdHistory.length > 0) {
        if (cmdHistoryIndex > 0) cmdHistoryIndex--;
        quickCmdInput.value = cmdHistory[cmdHistoryIndex] || '';
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (cmdHistory.length > 0) {
        if (cmdHistoryIndex < cmdHistory.length - 1) {
          cmdHistoryIndex++;
          quickCmdInput.value = cmdHistory[cmdHistoryIndex] || '';
        } else {
          cmdHistoryIndex = cmdHistory.length;
          quickCmdInput.value = '';
        }
      }
    }
  });

  /* ==========================================================
     LOGOUT
     ========================================================== */
  logoutBtn.addEventListener('click', function () {
    apiFetch('/api/logout', { method: 'POST' })
      .then(function () {
        localStorage.removeItem('wt_token');
        window.location.href = '/';
      })
      .catch(function () {
        localStorage.removeItem('wt_token');
        window.location.href = '/';
      });
  });

  /* ==========================================================
     INIT
     ========================================================== */
  (function init() {
    if (!getToken()) return;

    // Show placeholder in quick cmd output
    var ph = document.createElement('div');
    ph.className = 'cmd-placeholder';
    ph.textContent = 'Select a connection, type a command, and press Enter (or click Execute) to run it on the remote server.';
    quickCmdOutput.appendChild(ph);

    loadConnections();
  })();

})();