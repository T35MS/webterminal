/* ==========================================================================
   Web Terminal — Terminal Logic (multi-tab, one tab per tmux session)
   Protocol (JSON text frames over WebSocket):
     Client -> Server: {"type":"input","data":"<str>"}
                      {"type":"resize","cols":N,"rows":N}
     Server -> Client: {"type":"output","data":"<str>"}
   Also accepts raw strings / ArrayBuffer from server as terminal output.
   ========================================================================== */

(function () {
  'use strict';

  /* ---------- Theme palettes ---------- */
  var THEMES = {
    dark: {
      background: '#0d1117', foreground: '#e6edf3',
      cursor: '#58a6ff', cursorAccent: '#0d1117',
      selectionBackground: 'rgba(88,166,255,0.3)',
      black: '#0d1117', red: '#ff7b72', green: '#3fb950',
      yellow: '#d29922', blue: '#58a6ff', magenta: '#bc8cff',
      cyan: '#39c5cf', white: '#b1bac4',
      brightBlack: '#6e7681', brightRed: '#ffa198', brightGreen: '#56d364',
      brightYellow: '#e3b341', brightBlue: '#79c0ff', brightMagenta: '#d2a8ff',
      brightCyan: '#56d4dd', brightWhite: '#f0f6fc'
    },
    light: {
      background: '#ffffff', foreground: '#24292f',
      cursor: '#0969da', cursorAccent: '#ffffff',
      selectionBackground: 'rgba(9,105,218,0.2)',
      black: '#24292f', red: '#cf222e', green: '#1a7f37',
      yellow: '#9a6700', blue: '#0969da', magenta: '#8250df',
      cyan: '#1b7c83', white: '#6e7781',
      brightBlack: '#57606a', brightRed: '#a40e26', brightGreen: '#2da44e',
      brightYellow: '#bf8700', brightBlue: '#218bff', brightMagenta: '#a475f9',
      brightCyan: '#3192aa', brightWhite: '#8c959f'
    },
    solarized: {
      background: '#002b36', foreground: '#839496',
      cursor: '#93a1a1', cursorAccent: '#002b36',
      selectionBackground: 'rgba(131,148,150,0.3)',
      black: '#073642', red: '#dc322f', green: '#859900',
      yellow: '#b58900', blue: '#268bd2', magenta: '#d33682',
      cyan: '#2aa198', white: '#eee8d5',
      brightBlack: '#586e75', brightRed: '#cb4b16', brightGreen: '#586e75',
      brightYellow: '#657b83', brightBlue: '#839496', brightMagenta: '#6c71c4',
      brightCyan: '#93a1a1', brightWhite: '#fdf6e3'
    },
    dracula: {
      background: '#282a36', foreground: '#f8f8f2',
      cursor: '#f8f8f2', cursorAccent: '#282a36',
      selectionBackground: 'rgba(68,71,90,0.6)',
      black: '#21222c', red: '#ff5555', green: '#50fa7b',
      yellow: '#f1fa8c', blue: '#bd93f9', magenta: '#ff79c6',
      cyan: '#8be9fd', white: '#f8f8f2',
      brightBlack: '#6272a4', brightRed: '#ff6e6e', brightGreen: '#69ff94',
      brightYellow: '#ffffa5', brightBlue: '#d6acff', brightMagenta: '#ff92df',
      brightCyan: '#a4ffff', brightWhite: '#ffffff'
    },
    monokai: {
      background: '#272822', foreground: '#f8f8f2',
      cursor: '#f8f8f0', cursorAccent: '#272822',
      selectionBackground: 'rgba(73,72,62,0.6)',
      black: '#272822', red: '#f92672', green: '#a6e22e',
      yellow: '#f4bf75', blue: '#66d9ef', magenta: '#ae81ff',
      cyan: '#a1efe4', white: '#f8f8f2',
      brightBlack: '#75715e', brightRed: '#f92672', brightGreen: '#a6e22e',
      brightYellow: '#f4bf75', brightBlue: '#66d9ef', brightMagenta: '#ae81ff',
      brightCyan: '#a1efe4', brightWhite: '#f9f8f5'
    }
  };

  /* ---------- DOM ---------- */
  var termArea = document.getElementById('terminalArea');
  var tabbarTabs = document.getElementById('tabbarTabs');
  var tabNewBtn = document.getElementById('tabNewBtn');
  var connStatus = document.getElementById('connStatus');
  var connText = connStatus.querySelector('.conn-text');
  var settingsBtn = document.getElementById('settingsBtn');
  var settingsPanel = document.getElementById('settingsPanel');
  var closeSettingsBtn = document.getElementById('closeSettings');
  var overlay = document.getElementById('overlay');
  var logoutBtn = document.getElementById('logoutBtn');
  var themeSelect = document.getElementById('themeSelect');
  var fontFamilySelect = document.getElementById('fontFamilySelect');
  var fontSizeRange = document.getElementById('fontSizeRange');
  var fontSizeValue = document.getElementById('fontSizeValue');
  var saveApplyBtn = document.getElementById('saveApplyBtn');
  var resetBtn = document.getElementById('resetSettings');
  var changePwForm = document.getElementById('changePwForm');
  var oldPw = document.getElementById('oldPw');
  var newPw = document.getElementById('newPw');
  var confirmPw = document.getElementById('confirmPw');
  var pwMsg = document.getElementById('pwMsg');
  var changePwBtn = document.getElementById('changePwBtn');
  var toastContainer = document.getElementById('toastContainer');

  /* ---------- State ---------- */
  var tabs = [];            // {id,name,term,fit,webgl,host,socket,status,reconnectTimer,reconnectAttempts}
  var activeTabId = null;
  var tabSeq = 0;
  var config = {
    theme: 'dark',
    fontSize: 14,
    fontFamily: "'Fira Code', 'Cascadia Code', monospace"
  };

  /* ---------- Token ---------- */
  function getToken() { return localStorage.getItem('wt_token'); }
  function clearToken() { localStorage.removeItem('wt_token'); }

  /* ---------- Toast ---------- */
  function toast(msg, type) {
    var el = document.createElement('div');
    el.className = 'toast ' + (type || 'info');
    el.textContent = msg;
    toastContainer.appendChild(el);
    setTimeout(function () {
      el.classList.add('fade-out');
      setTimeout(function () { el.remove(); }, 300);
    }, 3000);
  }

  /* ---------- Topbar connection status ---------- */
  function setConnState(state, text) {
    connStatus.setAttribute('data-state', state);
    connText.textContent = text || state;
  }

  function getTab(id) {
    for (var i = 0; i < tabs.length; i++) if (tabs[i].id === id) return tabs[i];
    return null;
  }
  function getActiveTab() { return activeTabId === null ? null : getTab(activeTabId); }
  /* ---------- Tab rendering ---------- */
  function renderTabs() {
    tabbarTabs.innerHTML = '';
    tabs.forEach(function (tab) {
      var el = document.createElement('button');
      el.className = 'tab-item' + (tab.id === activeTabId ? ' active' : '');
      el.title = 'tmux session: ' + tab.name;

      var dot = document.createElement('span');
      dot.className = 'tab-status ' + tab.status;

      var label = document.createElement('span');
      label.className = 'tab-label';
      label.textContent = tab.name;

      var close = document.createElement('span');
      close.className = 'tab-close';
      close.title = 'Close tab (kills tmux session)';
      close.innerHTML = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
      close.addEventListener('click', function (e) {
        e.stopPropagation();
        closeTab(tab.id);
      });

      el.appendChild(dot);
      el.appendChild(label);
      el.appendChild(close);
      el.addEventListener('click', function () { activateTab(tab.id); });
      tabbarTabs.appendChild(el);
    });
  }

  function setTabStatus(tab, state) {
    tab.status = state;
    var idx = tabs.indexOf(tab);
    var el = tabbarTabs.children[idx];
    if (el) {
      var dot = el.querySelector('.tab-status');
      if (dot) dot.className = 'tab-status ' + state;
    }
    if (tab.id === activeTabId) setConnState(state, state.charAt(0).toUpperCase() + state.slice(1));
  }

  /* ---------- Tab lifecycle ---------- */
  function createTab(sessionName, makeActive) {
    var tab = {
      id: ++tabSeq,
      name: sessionName,
      term: null, fit: null, webgl: null, host: null,
      socket: null, status: 'connecting',
      reconnectTimer: null, reconnectAttempts: 0, lastCols: 0, lastRows: 0
    };
    tabs.push(tab);

    // Host div per tab. Non-active tabs use visibility:hidden + off-screen
    // (NOT display:none) so xterm has non-zero dimensions during open().
    tab.host = document.createElement('div');
    tab.host.className = 'terminal-host';
    if (makeActive === false) {
      tab.host.style.position = 'absolute';
      tab.host.style.left = '-9999px';
      tab.host.style.top = '0';
      tab.host.style.width = '100%';
      tab.host.style.height = '100%';
    }
    termArea.appendChild(tab.host);

    initTerminalFor(tab);
    connectWSFor(tab);
    renderTabs();
    if (makeActive !== false) {
      activateTab(tab.id);
    }
    return tab;
  }

  function activateTab(id) {
    var tab = getTab(id);
    if (!tab) return;
    activeTabId = id;
    tabs.forEach(function (t) {
      if (t.id === id) {
        // Restore to visible, normal flow
        t.host.style.position = '';
        t.host.style.left = '';
        t.host.style.top = '';
        t.host.style.width = '';
        t.host.style.height = '';
        t.host.style.display = '';
      } else {
        // Hide non-active tabs off-screen (keeps xterm dimensions valid)
        t.host.style.position = 'absolute';
        t.host.style.left = '-9999px';
        t.host.style.top = '0';
        t.host.style.width = '100%';
        t.host.style.height = '100%';
        t.host.style.display = '';
      }
    });
    renderTabs();
    setConnState(tab.status, tab.status.charAt(0).toUpperCase() + tab.status.slice(1));
    requestAnimationFrame(function () {
      try { tab.fit.fit(); } catch (e) {}
      try { tab.term.focus(); } catch (e) {}
    });
  }

  function closeTab(id) {
    var tab = getTab(id);
    if (!tab) return;
    if (!confirm('Close tab "' + tab.name + '"?\nThe tmux session will be killed.')) return;

    if (tab.reconnectTimer) clearTimeout(tab.reconnectTimer);
    if (tab.socket) { try { tab.socket.onclose = null; tab.socket.close(); } catch (e) {} }
    try { if (tab.webgl) tab.term._core.dispose(); } catch (e) {}
    try { tab.term.dispose(); } catch (e) {}
    tab.host.remove();
    fetch('/api/sessions/' + encodeURIComponent(tab.name) + '/kill', { method: 'POST', credentials: 'include' })
      .catch(function () {});
    tabs = tabs.filter(function (t) { return t.id !== id; });

    if (activeTabId === id) {
      if (tabs.length) activateTab(tabs[tabs.length - 1].id);
      else createNewSessionTab();
    }
    renderTabs();
    toast('Tab "' + tab.name + '" closed', 'info');
  }

  function createNewSessionTab() {
    fetch('/api/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({})
    })
      .then(function (r) { return r.json().catch(function () { return {}; }); })
      .then(function (data) {
        if (data && data.name) {
          createTab(data.name);
          toast('New tab: ' + data.name, 'success');
        } else {
          toast(data.error || 'Failed to create session', 'error');
        }
      })
      .catch(function () { toast('Network error', 'error'); });
  }

  /* ---------- Terminal init (per tab) ---------- */
  function initTerminalFor(tab) {
    var theme = THEMES[config.theme] || THEMES.dark;
    tab.term = new Terminal({
      cursorBlink: true,
      cursorStyle: 'bar',
      fontSize: config.fontSize,
      fontFamily: config.fontFamily,
      allowProposedApi: true,
      scrollback: 10000,
      theme: theme
    });

    tab.fit = new FitAddon.FitAddon();
    tab.term.loadAddon(tab.fit);

    try { tab.term.loadAddon(new WebLinksAddon.WebLinksAddon()); } catch (e) {}
    try {
      tab.webgl = new WebglAddon.WebglAddon();
      tab.term.loadAddon(tab.webgl);
    } catch (e) { tab.webgl = null; }

    tab.term.open(tab.host);
    tab.fit.fit();

    tab.term.onData(function (data) {
      wsSendFor(tab, { type: 'data', data: data });
    });

    tab.term.onResize(function (size) {
      if (size.cols !== tab.lastCols || size.rows !== tab.lastRows) {
        tab.lastCols = size.cols;
        tab.lastRows = size.rows;
        wsSendFor(tab, { type: 'resize', cols: size.cols, rows: size.rows });
      }
    });
  }
  /* ---------- WebSocket (per tab) ---------- */
  function connectWSFor(tab) {
    var token = getToken();
    if (!token) { window.location.href = '/'; return; }

    setTabStatus(tab, 'connecting');
    var proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    var url = proto + '//' + location.host + '/ws?token=' + encodeURIComponent(token) +
              '&session=' + encodeURIComponent(tab.name);

    try { tab.socket = new WebSocket(url); } catch (e) {
      setTabStatus(tab, 'disconnected');
      scheduleReconnectFor(tab);
      return;
    }
    tab.socket.binaryType = 'arraybuffer';

    tab.socket.onopen = function () {
      tab.reconnectAttempts = 0;
      setTabStatus(tab, 'connected');
      wsSendFor(tab, { type: 'resize', cols: tab.term.cols, rows: tab.term.rows });
    };

    tab.socket.onmessage = function (event) {
      var raw = event.data;
      if (typeof raw === 'string') {
        try {
          var msg = JSON.parse(raw);
          if (msg) {
            if (msg.type === 'data' && typeof msg.data === 'string') {
              tab.term.write(msg.data);
            } else if (msg.type === 'ready') {
              setTabStatus(tab, 'connected');
            } else if (msg.type === 'exit') {
              setTabStatus(tab, 'disconnected');
            }
          }
        } catch (_) { tab.term.write(raw); }
      } else if (raw instanceof ArrayBuffer) {
        tab.term.write(new TextDecoder('utf-8').decode(new Uint8Array(raw)));
      }
    };

    tab.socket.onerror = function () {};

    tab.socket.onclose = function (ev) {
      tab.socket = null;
      if (ev.code === 1008) {
        localStorage.removeItem('wt_token');
        window.location.href = '/';
        return;
      }
      setTabStatus(tab, 'disconnected');
      scheduleReconnectFor(tab);
    };
  }

  function wsSendFor(tab, msg) {
    if (tab.socket && tab.socket.readyState === WebSocket.OPEN) {
      tab.socket.send(JSON.stringify(msg));
    }
  }

  function scheduleReconnectFor(tab) {
    if (tab.reconnectTimer) clearTimeout(tab.reconnectTimer);
    tab.reconnectAttempts++;
    var delay = Math.min(1000 * Math.pow(1.5, tab.reconnectAttempts), 10000);
    tab.reconnectTimer = setTimeout(function () { connectWSFor(tab); }, delay);
  }

  /* ---------- Fit / window resize ---------- */
  var resizeTO = null;
  window.addEventListener('resize', function () {
    if (resizeTO) clearTimeout(resizeTO);
    resizeTO = setTimeout(function () {
      tabs.forEach(function (t) { try { t.fit.fit(); } catch (e) {} });
    }, 100);
  });

  /* ---------- Apply config to all tabs ---------- */
  function applyConfig() {
    var theme = THEMES[config.theme] || THEMES.dark;
    tabs.forEach(function (tab) {
      if (!tab.term) return;
      tab.term.options.theme = theme;
      tab.term.options.fontSize = config.fontSize;
      tab.term.options.fontFamily = config.fontFamily;
      try { tab.fit.fit(); } catch (e) {}
    });
  }

  function syncSettingsUI() {
    themeSelect.value = config.theme;
    fontFamilySelect.value = config.fontFamily;
    fontSizeRange.value = config.fontSize;
    fontSizeValue.textContent = config.fontSize + 'px';
  }
  /* ---------- Settings panel ---------- */
  function openSettings() {
    settingsPanel.classList.add('open');
    settingsPanel.setAttribute('aria-hidden', 'false');
    overlay.hidden = false;
    requestAnimationFrame(function () { overlay.classList.add('visible'); });
    loadConfig();
  }

  function closeSettingsPanel() {
    settingsPanel.classList.remove('open');
    settingsPanel.setAttribute('aria-hidden', 'true');
    overlay.classList.remove('visible');
    setTimeout(function () { overlay.hidden = true; }, 300);
  }

  settingsBtn.addEventListener('click', openSettings);
  closeSettingsBtn.addEventListener('click', closeSettingsPanel);
  overlay.addEventListener('click', closeSettingsPanel);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && settingsPanel.classList.contains('open')) closeSettingsPanel();
  });

  themeSelect.addEventListener('change', function () { config.theme = themeSelect.value; applyConfig(); });
  fontFamilySelect.addEventListener('change', function () { config.fontFamily = fontFamilySelect.value; applyConfig(); });
  fontSizeRange.addEventListener('input', function () {
    var v = parseInt(fontSizeRange.value, 10);
    fontSizeValue.textContent = v + 'px';
    config.fontSize = v;
    applyConfig();
  });

  /* ---------- Load config from server ---------- */
  function loadConfig() {
    fetch('/api/config', { credentials: 'include' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        if (!data) return;
        if (data.theme) config.theme = data.theme;
        if (data.fontSize) config.fontSize = data.fontSize;
        if (data.fontFamily) config.fontFamily = data.fontFamily;
        syncSettingsUI();
        applyConfig();
      })
      .catch(function () {});
  }

  /* ---------- Save & Apply ---------- */
  saveApplyBtn.addEventListener('click', function () {
    saveApplyBtn.disabled = true;
    saveApplyBtn.textContent = 'Saving…';
    fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ theme: config.theme, fontSize: config.fontSize, fontFamily: config.fontFamily })
    })
      .then(function (r) {
        if (r.ok) { toast('Settings saved', 'success'); applyConfig(); }
        else { toast('Failed to save settings', 'error'); }
      })
      .catch(function () { toast('Network error', 'error'); })
      .finally(function () {
        saveApplyBtn.disabled = false;
        saveApplyBtn.textContent = 'Save & Apply';
      });
  });

  resetBtn.addEventListener('click', function () {
    config = { theme: 'dark', fontSize: 14, fontFamily: "'Fira Code', 'Cascadia Code', monospace" };
    syncSettingsUI();
    applyConfig();
    toast('Preview reset — click Save & Apply to persist', 'info');
  });

  /* ---------- Change password ---------- */
  function showPwMsg(msg, type) {
    pwMsg.hidden = false;
    pwMsg.textContent = msg;
    pwMsg.className = 'msg-box ' + type;
  }

  changePwForm.addEventListener('submit', function (e) {
    e.preventDefault();
    pwMsg.hidden = true;
    if (!newPw.value) { showPwMsg('New password cannot be empty.', 'error'); return; }
    if (newPw.value !== confirmPw.value) { showPwMsg('Passwords do not match.', 'error'); return; }

    changePwBtn.disabled = true;
    changePwBtn.textContent = 'Updating…';
    fetch('/api/change-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ oldPassword: oldPw.value, newPassword: newPw.value })
    })
      .then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (data) {
          if (r.ok) {
            showPwMsg('Password updated successfully.', 'success');
            changePwForm.reset();
            toast('Password changed', 'success');
          } else {
            showPwMsg(data.error || data.message || ('Failed (HTTP ' + r.status + ').'), 'error');
          }
        });
      })
      .catch(function () { showPwMsg('Network error. Please try again.', 'error'); })
      .finally(function () {
        changePwBtn.disabled = false;
        changePwBtn.textContent = 'Update Password';
      });
  });

  /* ---------- New tab button ---------- */
  tabNewBtn.addEventListener('click', createNewSessionTab);

  /* ---------- Logout ---------- */
  logoutBtn.addEventListener('click', function () {
    logoutBtn.disabled = true;
    fetch('/api/logout', { method: 'POST', credentials: 'include' })
      .catch(function () {})
      .finally(function () {
        clearToken();
        window.location.href = '/';
      });
  });

  /* ---------- Init ---------- */
  function init() {
    fetch('/api/config', { credentials: 'include' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        if (data) {
          if (data.theme) config.theme = data.theme;
          if (data.fontSize) config.fontSize = data.fontSize;
          if (data.fontFamily) config.fontFamily = data.fontFamily;
        }
      })
      .catch(function () {})
      .finally(function () {
        syncSettingsUI();
        // Open a tab for EVERY existing tmux session so previous sessions are
        // quickly reachable, like browser tabs. If none exist, create 'main'.
        fetch('/api/sessions', { credentials: 'include' })
          .then(function (r) { return r.ok ? r.json() : null; })
          .then(function (data) {
            var names = (data && data.sessions && data.sessions.length)
              ? data.sessions.map(function (s) { return s.name; })
              : [SESSION_DEFAULT];
            // Create first tab as active (visible for xterm render),
            // remaining tabs hidden — they'll fit() when activated.
            names.forEach(function (n, i) { createTab(n, i === 0); });
          })
          .catch(function () { createTab(SESSION_DEFAULT, true); });
      });
  }

  var SESSION_DEFAULT = 'main';
  init();
})();
