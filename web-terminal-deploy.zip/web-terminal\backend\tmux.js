// tmux.js - tmux session management.
//
// Sessions are created detached and persist across client disconnects. We
// attach to a session by spawning `tmux attach -t <name>` inside a node-pty
// pseudo-terminal; data from the PTY is piped to the WebSocket and vice versa.
// On disconnect we simply kill the PTY (which detaches from tmux) - the tmux
// session itself keeps running.

const { spawn, execFile } = require('child_process');
const os = require('os');

const TMUX_BIN = process.env.TMUX_BIN || 'tmux';
const DEFAULT_SHELL = process.env.SHELL || '/bin/bash';

function execTmux(args, opts = {}) {
  return new Promise((resolve, reject) => {
    execFile(TMUX_BIN, args, { maxBuffer: 4 * 1024 * 1024, ...opts }, (err, stdout, stderr) => {
      if (err) {
        // tmux prints messages to stderr; include them for diagnostics.
        const msg = stderr ? stderr.toString().trim() : err.message;
        const e = new Error(msg);
        e.code = err.code;
        e.stderr = stderr ? stderr.toString() : '';
        e.stdout = stdout ? stdout.toString() : '';
        reject(e);
      } else {
        resolve({
          stdout: stdout ? stdout.toString() : '',
          stderr: stderr ? stderr.toString() : ''
        });
      }
    });
  });
}

// Returns true if a tmux session with the given name exists.
async function sessionExists(sessionName) {
  try {
    await execTmux(['has-session', '-t', sessionName]);
    return true;
  } catch {
    return false;
  }
}

// Create a detached tmux session if it does not already exist.
// Returns true if a new session was created.
async function ensureSession(sessionName, opts = {}) {
  const exists = await sessionExists(sessionName);
  if (exists) return false;

  const shell = opts.shell || DEFAULT_SHELL;
  const cwd = opts.cwd || os.homedir();
  // Create a new detached session. -d = don't attach. The session runs the
  // configured shell inside it.
  await execTmux(['new-session', '-d', '-s', sessionName, '-x', '180', '-y', '50', shell], {
    cwd
  });
  return true;
}

// Attach to an existing session by spawning `tmux attach -t <name>` in a PTY.
//
// node-pty is the right tool here because tmux is a TUI program that needs a
// real pseudo-terminal to render into. We return an object with the pty
// process, a write() method, a resize() method, and an onData/onExit callback
// registration. The caller is responsible for destroying the pty on
// disconnect (which detaches from the tmux session without killing it).
async function attachSession(sessionName, opts = {}) {
  const exists = await sessionExists(sessionName);
  if (!exists) {
    throw new Error(`tmux session "${sessionName}" does not exist`);
  }

  // node-pty is a native module; require lazily so the rest of the server can
  // boot even if the native build is missing (e.g. during pure HTTP testing).
  let pty;
  try {
    pty = require('node-pty');
  } catch (err) {
    throw new Error(`node-pty is not available: ${err.message}`);
  }

  const cols = opts.cols || 80;
  const rows = opts.rows || 24;
  const cwd = opts.cwd || os.homedir();

  const proc = pty.spawn(TMUX_BIN, ['attach', '-t', sessionName], {
    name: 'xterm-256color',
    cols,
    rows,
    cwd,
    env: { ...process.env, TERM: 'xterm-256color' }
  });
  return proc;
}

// List active tmux sessions. Returns an array of { name, created, attached, windows }.
async function listSessions() {
  try {
    const res = await execTmux([
      'list-sessions',
      '-F',
      '#{session_name}\t#{session_created_string}\t#{session_attached}\t#{session_windows}'
    ]);
    if (!res.stdout.trim()) return [];
    return res.stdout
      .trim()
      .split('\n')
      .map((line) => {
        const [name, created, attached, windows] = line.split('\t');
        return {
          name,
          created,
          attached: attached === '1',
          windows: parseInt(windows, 10) || 1
        };
      });
  } catch (err) {
    // tmux returns exit code 1 when there are no sessions or when no tmux
    // server is running yet. Treat both as an empty list.
    if (/no server running|no sessions|error connecting to/i.test(err.message)) return [];
    throw err;
  }
}

// Kill a tmux session by name.
async function killSession(sessionName) {
  await execTmux(['kill-session', '-t', sessionName]);
}

// Create a new window in an existing session.
async function newWindow(sessionName, name) {
  const args = ['new-window', '-t', sessionName];
  if (name) args.push('-n', name);
  await execTmux(args);
}

// Split a pane. direction: 'h' (horizontal split / side by side) or 'v'
// (vertical split / stacked). Returns nothing.
async function splitPane(sessionName, direction) {
  const flag = direction === 'h' ? '-h' : '-v';
  await execTmux(['split-window', flag, '-t', sessionName]);
}

// Select the next/previous window, or a specific window by index.
async function selectWindow(sessionName, target) {
  await execTmux(['select-window', '-t', `${sessionName}:${target}`]);
}

// Send keys to a session (e.g. to run a command). appendEnter sends a Return.
async function sendKeys(sessionName, keys, appendEnter = true) {
  const args = ['send-keys', '-t', sessionName, keys];
  if (appendEnter) args.push('Enter');
  await execTmux(args);
}

module.exports = {
  execTmux,
  sessionExists,
  ensureSession,
  attachSession,
  listSessions,
  killSession,
  newWindow,
  splitPane,
  selectWindow,
  sendKeys
};