// files.js - File manager API routes for the web terminal backend.
//
// Exports a factory function that takes the `requireAuth` middleware and
// returns an Express router. Mount in server.js with:
//
//     app.use('/api/files', require('./files')(requireAuth));
//
// Endpoints (all require auth):
//   GET  /list?path=<dir>      List directory contents
//   GET  /read?path=<file>     Read file content as UTF-8 text
//   POST /write                Write content to a file
//   POST /mkdir                Create a directory recursively
//   POST /delete               Delete a file or directory
//   POST /rename               Rename/move a file or directory
//   GET  /download?path=<file> Download a file as an attachment (streamed)
//   POST /upload               Upload a file (multipart, field "file", optional "path")
//   GET  /stat?path=<file>     Get file stat info

const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const express = require('express');
const multer = require('multer');

// Root workspace directory. All file operations are constrained to be within
// this directory to prevent path traversal. Override via env var.
const ROOT_DIR = path.resolve(process.env.WEB_TERMINAL_ROOT || '/home/ubuntu');

// Limits.
const MAX_TEXT_SIZE = 10 * 1024 * 1024; // 10 MB for text reads
const MAX_UPLOAD_SIZE = 100 * 1024 * 1024; // 100 MB for uploads (multer limit)
// Number of bytes to inspect when deciding whether a file is binary.
const BINARY_SNIFF_BYTES = 8000;

// Multer: keep files in memory so we can validate the destination before
// writing. Limits enforced by MAX_UPLOAD_SIZE.
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_UPLOAD_SIZE }
});

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

// Resolve a user-supplied path relative to ROOT_DIR and verify the resolved
// path is still within ROOT_DIR. Returns the absolute resolved path string.
// Throws an Error (with a clear message) if the path escapes the root.
function safeResolve(userPath) {
  // If no path provided, default to root directory.
  if (typeof userPath !== 'string' || userPath.length === 0) {
    return path.resolve(ROOT_DIR);
  }
  // If the user passes an absolute path that is already inside root, accept it;
  // otherwise treat it as relative to root.
  const base = path.isAbsolute(userPath) ? userPath : path.join(ROOT_DIR, userPath);
  const resolved = path.resolve(base);
  // Normalize root once for the containment check.
  const normalizedRoot = path.resolve(ROOT_DIR);
  // Allow the root itself; otherwise must start with root + sep.
  if (resolved !== normalizedRoot && !resolved.startsWith(normalizedRoot + path.sep)) {
    throw new Error('Access denied: path outside workspace root');
  }
  return resolved;
}

// Get the extension (without dot) lowercased, or '' for none.
function getExt(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return ext.startsWith('.') ? ext.slice(1) : ext;
}

// Heuristic: detect whether a file is binary by scanning the first N bytes for
// NUL bytes or a high proportion of non-text bytes.
function isBinaryBuffer(buf) {
  const len = Math.min(buf.length, BINARY_SNIFF_BYTES);
  if (len === 0) return false;
  let suspicious = 0;
  for (let i = 0; i < len; i++) {
    const byte = buf[i];
    // NUL byte is a strong binary signal.
    if (byte === 0) return true;
    // Count control chars except common text ones (tab, newline, carriage return).
    if (byte < 7 || (byte > 14 && byte < 32)) {
      suspicious++;
    }
  }
  // If >30% suspicious bytes in the sniff window, treat as binary.
  return suspicious / len > 0.3;
}

// Build a file-info object from a directory entry + stats.
function fileInfo(name, fullPath) {
  return {
    name,
    path: path.relative(ROOT_DIR, fullPath) || name,
    isDir: false,
    size: 0,
    modified: null,
    ext: getExt(name)
  };
}

// ---------------------------------------------------------------------------

module.exports = function createFilesRouter(requireAuth) {
  const router = express.Router();

  // Every route in this router requires auth.
  router.use(requireAuth);

  // ----- GET /list?path=<dir> --------------------------------------------
  router.get('/list', async (req, res) => {
    let dirPath;
    try {
      dirPath = safeResolve(req.query.path || '.');
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
    try {
      const stat = await fsp.stat(dirPath);
      if (!stat.isDirectory()) {
        return res.status(400).json({ error: 'Path is not a directory' });
      }
      const entries = await fsp.readdir(dirPath, { withFileTypes: true });
      const items = await Promise.all(
        entries.map(async (entry) => {
          const fullPath = path.join(dirPath, entry.name);
          let st;
          try {
            st = await fsp.stat(fullPath);
          } catch {
            // Broken symlink or inaccessible: still list with zeros.
            st = { size: 0, mtime: 0, isDirectory: () => entry.isDirectory() };
          }
          return {
            name: entry.name,
            path: path.relative(ROOT_DIR, fullPath) || entry.name,
            isDir: st.isDirectory(),
            size: st.isDirectory() ? 0 : st.size,
            modified: st.mtime ? st.mtime.getTime() : 0,
            ext: st.isDirectory() ? '' : getExt(entry.name)
          };
        })
      );
      // Sort: directories first, then files; both alphabetical (case-insensitive).
      items.sort((a, b) => {
        if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
        return a.name.localeCompare(b.name, undefined, { sensitivity: 'base' });
      });
      return res.json(items);
    } catch (err) {
      if (err.code === 'ENOENT') return res.status(404).json({ error: 'Directory not found' });
      if (err.code === 'EACCES') return res.status(403).json({ error: 'Permission denied' });
      return res.status(500).json({ error: err.message });
    }
  });

  // ----- GET /read?path=<file> -------------------------------------------
  router.get('/read', async (req, res) => {
    let filePath;
    try {
      filePath = safeResolve(req.query.path || '.');
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
    try {
      const stat = await fsp.stat(filePath);
      if (stat.isDirectory()) {
        return res.status(400).json({ error: 'Cannot read a directory' });
      }
      if (stat.size > MAX_TEXT_SIZE) {
        return res.status(413).json({
          error: `File too large for text read (max ${MAX_TEXT_SIZE} bytes, got ${stat.size})`
        });
      }
      // Read a sniff buffer first to detect binary files.
      const handle = await fsp.open(filePath, 'r');
      try {
        const sniff = Buffer.alloc(Math.min(stat.size, BINARY_SNIFF_BYTES));
        if (stat.size > 0) {
          await handle.read(sniff, 0, sniff.length, 0);
        }
        if (isBinaryBuffer(stat.size > 0 ? sniff : Buffer.alloc(0))) {
          return res.status(415).json({ error: 'File appears to be binary; use the download endpoint instead' });
        }
      } finally {
        await handle.close();
      }
      const content = await fsp.readFile(filePath, 'utf8');
      return res.json({
        path: path.relative(ROOT_DIR, filePath),
        content,
        size: stat.size,
        ext: getExt(filePath)
      });
    } catch (err) {
      if (err.code === 'ENOENT') return res.status(404).json({ error: 'File not found' });
      if (err.code === 'EACCES') return res.status(403).json({ error: 'Permission denied' });
      return res.status(500).json({ error: err.message });
    }
  });

  // ----- POST /write {path, content} -------------------------------------
  router.post('/write', async (req, res) => {
    const { path: relPath, content } = req.body || {};
    if (typeof relPath !== 'string' || relPath.length === 0) {
      return res.status(400).json({ error: 'path is required' });
    }
    const text = typeof content === 'string' ? content : '';
    let filePath;
    try {
      filePath = safeResolve(relPath);
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
    try {
      const parent = path.dirname(filePath);
      await fsp.mkdir(parent, { recursive: true });
      const buf = Buffer.from(text, 'utf8');
      await fsp.writeFile(filePath, buf, 'utf8');
      return res.json({ success: true, path: path.relative(ROOT_DIR, filePath), size: buf.length });
    } catch (err) {
      if (err.code === 'EACCES') return res.status(403).json({ error: 'Permission denied' });
      if (err.code === 'EISDIR') return res.status(400).json({ error: 'Path is a directory' });
      return res.status(500).json({ error: err.message });
    }
  });

  // ----- POST /mkdir {path} ----------------------------------------------
  router.post('/mkdir', async (req, res) => {
    const { path: relPath } = req.body || {};
    if (typeof relPath !== 'string' || relPath.length === 0) {
      return res.status(400).json({ error: 'path is required' });
    }
    let dirPath;
    try {
      dirPath = safeResolve(relPath);
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
    try {
      await fsp.mkdir(dirPath, { recursive: true });
      return res.json({ success: true, path: path.relative(ROOT_DIR, dirPath) });
    } catch (err) {
      if (err.code === 'EACCES') return res.status(403).json({ error: 'Permission denied' });
      return res.status(500).json({ error: err.message });
    }
  });

  // ----- POST /delete {path} ---------------------------------------------
  router.post('/delete', async (req, res) => {
    const { path: relPath } = req.body || {};
    if (typeof relPath !== 'string' || relPath.length === 0) {
      return res.status(400).json({ error: 'path is required' });
    }
    let targetPath;
    try {
      targetPath = safeResolve(relPath);
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
    try {
      // Prevent deleting the root itself.
      if (targetPath === path.resolve(ROOT_DIR)) {
        return res.status(400).json({ error: 'Cannot delete workspace root' });
      }
      const stat = await fsp.stat(targetPath);
      if (stat.isDirectory()) {
        await fsp.rm(targetPath, { recursive: true, force: false });
      } else {
        await fsp.unlink(targetPath);
      }
      return res.json({ success: true, path: path.relative(ROOT_DIR, targetPath) });
    } catch (err) {
      if (err.code === 'ENOENT') return res.status(404).json({ error: 'Path not found' });
      if (err.code === 'EACCES') return res.status(403).json({ error: 'Permission denied' });
      return res.status(500).json({ error: err.message });
    }
  });

  // ----- POST /rename {oldPath, newPath} ---------------------------------
  router.post('/rename', async (req, res) => {
    const { oldPath, newPath } = req.body || {};
    if (typeof oldPath !== 'string' || oldPath.length === 0) {
      return res.status(400).json({ error: 'oldPath is required' });
    }
    if (typeof newPath !== 'string' || newPath.length === 0) {
      return res.status(400).json({ error: 'newPath is required' });
    }
    let src, dest;
    try {
      src = safeResolve(oldPath);
      dest = safeResolve(newPath);
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
    try {
      // Ensure destination parent exists.
      await fsp.mkdir(path.dirname(dest), { recursive: true });
      await fsp.rename(src, dest);
      return res.json({
        success: true,
        oldPath: path.relative(ROOT_DIR, src),
        newPath: path.relative(ROOT_DIR, dest)
      });
    } catch (err) {
      if (err.code === 'ENOENT') return res.status(404).json({ error: 'Source not found' });
      if (err.code === 'EACCES') return res.status(403).json({ error: 'Permission denied' });
      return res.status(500).json({ error: err.message });
    }
  });

  // ----- GET /download?path=<file> ---------------------------------------
  router.get('/download', async (req, res) => {
    let filePath;
    try {
      filePath = safeResolve(req.query.path || '.');
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
    try {
      const stat = await fsp.stat(filePath);
      if (stat.isDirectory()) {
        return res.status(400).json({ error: 'Cannot download a directory' });
      }
      const fileName = path.basename(filePath);
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(fileName)}"`);
      res.setHeader('Content-Length', stat.size);
      // Stream the file directly.
      const stream = fs.createReadStream(filePath);
      stream.on('error', (err) => {
        if (!res.headersSent) {
          return res.status(500).json({ error: err.message });
        }
        // Headers already sent; just end the response.
        try { res.end(); } catch { /* ignore */ }
      });
      return stream.pipe(res);
    } catch (err) {
      if (err.code === 'ENOENT') return res.status(404).json({ error: 'File not found' });
      if (err.code === 'EACCES') return res.status(403).json({ error: 'Permission denied' });
      return res.status(500).json({ error: err.message });
    }
  });

  // ----- POST /upload (multipart: field "file", optional "path") ---------
  router.post('/upload', upload.single('file'), async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded (field name must be "file")' });
    }
    let destDir;
    try {
      destDir = safeResolve(req.body && req.body.path ? req.body.path : '.');
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
    try {
      // Ensure destination is (or becomes) a directory.
      try {
        const st = await fsp.stat(destDir);
        if (!st.isDirectory()) {
          return res.status(400).json({ error: 'Destination path is not a directory' });
        }
      } catch (err) {
        if (err.code === 'ENOENT') {
          await fsp.mkdir(destDir, { recursive: true });
        } else {
          throw err;
        }
      }
      const destFile = path.join(destDir, req.file.originalname);
      await fsp.writeFile(destFile, req.file.buffer);
      return res.json({
        success: true,
        path: path.relative(ROOT_DIR, destFile),
        name: req.file.originalname,
        size: req.file.size
      });
    } catch (err) {
      if (err.code === 'EACCES') return res.status(403).json({ error: 'Permission denied' });
      return res.status(500).json({ error: err.message });
    }
  });

  // ----- GET /stat?path=<file> -------------------------------------------
  router.get('/stat', async (req, res) => {
    let filePath;
    try {
      filePath = safeResolve(req.query.path || '.');
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
    try {
      const stat = await fsp.stat(filePath);
      // octal permission string, e.g. "0755"
      const mode = (stat.mode & 0o777).toString(8).padStart(4, '0');
      const info = {
        path: path.relative(ROOT_DIR, filePath),
        name: path.basename(filePath),
        size: stat.isDirectory() ? 0 : stat.size,
        modified: stat.mtime ? stat.mtime.getTime() : 0,
        created: stat.birthtime ? stat.birthtime.getTime() : (stat.ctime ? stat.ctime.getTime() : 0),
        isDir: stat.isDirectory(),
        ext: stat.isDirectory() ? '' : getExt(filePath),
        permissions: mode
      };
      return res.json(info);
    } catch (err) {
      if (err.code === 'ENOENT') return res.status(404).json({ error: 'Path not found' });
      if (err.code === 'EACCES') return res.status(403).json({ error: 'Permission denied' });
      return res.status(500).json({ error: err.message });
    }
  });

  return router;
};
