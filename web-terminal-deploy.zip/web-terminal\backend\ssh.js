// ssh.js - SSH manager for external VPS connections.
// Exports a factory: module.exports = function(requireAuth) { return router; }

const { Router } = require('express');
const { Client } = require('ssh2');
const multer = require('multer');
const config = require('./config');
const path = require('path');
const fs = require('fs');

const upload = multer({ storage: multer.memoryStorage() });

function getConnections() {
  const cfg = config.getConfig();
  if (!cfg.sshConnections) {
    cfg.sshConnections = [];
    config.updateConfig({ sshConnections: [] });
  }
  return cfg.sshConnections;
}

function getConnectionById(id) {
  return getConnections().find(c => String(c.id) === String(id));
}

function safeConn(c) {
  if (!c) return null;
  return { id: c.id, name: c.name, host: c.host, port: c.port, username: c.username };
}

function connectSSH(connInfo) {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    const opts = {
      host: connInfo.host,
      port: connInfo.port || 22,
      username: connInfo.username,
      readyTimeout: 15000,
    };
    if (connInfo.privateKey) {
      opts.privateKey = connInfo.privateKey;
    } else if (connInfo.password) {
      opts.password = connInfo.password;
    } else {
      return reject(new Error('No password or private key provided'));
    }

    conn.on('ready', () => resolve(conn));
    conn.on('error', (err) => reject(err));
    conn.connect(opts);
  });
}

function execCommand(conn, cmd) {
  return new Promise((resolve, reject) => {
    conn.exec(cmd, (err, stream) => {
      if (err) return reject(err);
      let stdout = '', stderr = '';
      stream.on('data', (d) => { stdout += d.toString(); });
      stream.stderr.on('data', (d) => { stderr += d.toString(); });
      stream.on('close', (code) => {
        resolve({ stdout, stderr, exitCode: code });
      });
    });
  });
}

module.exports = function(requireAuth) {
  const router = Router();
  router.use(requireAuth);

  // --- Connection CRUD ---

  // List connections
  router.get('/connections', (req, res) => {
    const conns = getConnections().map(safeConn);
    res.json({ connections: conns });
  });

  // Create connection
  router.post('/connections', (req, res) => {
    const { name, host, port, username, password, privateKey } = req.body || {};
    if (!name || !host || !username) {
      return res.status(400).json({ error: 'name, host, and username are required' });
    }
    const conns = getConnections();
    const id = Date.now().toString();
    const newConn = { id, name, host, port: port || 22, username, password: password || '', privateKey: privateKey || '' };
    conns.push(newConn);
    config.updateConfig({ sshConnections: conns });
    res.json({ success: true, connection: safeConn(newConn) });
  });

  // Update connection
  router.put('/connections/:id', (req, res) => {
    const { id } = req.params;
    const conn = getConnectionById(id);
    if (!conn) return res.status(404).json({ error: 'Connection not found' });
    const { name, host, port, username, password, privateKey } = req.body || {};
    if (name !== undefined) conn.name = name;
    if (host !== undefined) conn.host = host;
    if (port !== undefined) conn.port = port;
    if (username !== undefined) conn.username = username;
    if (password !== undefined) conn.password = password;
    if (privateKey !== undefined) conn.privateKey = privateKey;
    config.updateConfig({ sshConnections: getConnections() });
    res.json({ success: true, connection: safeConn(conn) });
  });

  // Delete connection
  router.delete('/connections/:id', (req, res) => {
    const { id } = req.params;
    const conns = getConnections();
    const idx = conns.findIndex(c => String(c.id) === String(id));
    if (idx === -1) return res.status(404).json({ error: 'Connection not found' });
    conns.splice(idx, 1);
    config.updateConfig({ sshConnections: conns });
    res.json({ success: true });
  });

  // Test connection (without saving)
  router.post('/test', async (req, res) => {
    const { host, port, username, password, privateKey } = req.body || {};
    if (!host || !username) {
      return res.status(400).json({ error: 'host and username are required' });
    }
    try {
      const conn = await connectSSH({ host, port, username, password, privateKey });
      const result = await execCommand(conn, 'echo connected');
      conn.end();
      res.json({ success: true, message: 'Connected successfully', stdout: result.stdout.trim() });
    } catch (err) {
      res.status(500).json({ error: 'Connection failed: ' + err.message });
    }
  });

  // Execute command on remote VPS
  router.post('/exec', async (req, res) => {
    const { connectionId, command } = req.body || {};
    if (!connectionId || !command) {
      return res.status(400).json({ error: 'connectionId and command are required' });
    }
    const connInfo = getConnectionById(connectionId);
    if (!connInfo) return res.status(404).json({ error: 'Connection not found' });
    try {
      const conn = await connectSSH(connInfo);
      const result = await execCommand(conn, command);
      conn.end();
      res.json({ success: true, ...result });
    } catch (err) {
      res.status(500).json({ error: 'SSH exec failed: ' + err.message });
    }
  });

  // --- SFTP file operations ---

  async function getSFTP(connectionId) {
    const connInfo = getConnectionById(connectionId);
    if (!connInfo) throw new Error('Connection not found');
    const conn = await connectSSH(connInfo);
    return new Promise((resolve, reject) => {
      conn.sftp((err, sftp) => {
        if (err) { conn.end(); return reject(err); }
        resolve({ conn, sftp });
    });
    });
  }

  // List remote files
  router.get('/files', async (req, res) => {
    const { connectionId, path: remotePath } = req.query;
    if (!connectionId) return res.status(400).json({ error: 'connectionId is required' });
    try {
      const { conn, sftp } = await getSFTP(connectionId);
      const dir = remotePath || '/';
      sftp.readdir(dir, (err, list) => {
        conn.end();
        if (err) return res.status(500).json({ error: 'SFTP readdir failed: ' + err.message });
        const files = list.map(item => ({
          name: item.filename,
          path: dir.endsWith('/') ? dir + item.filename : dir + '/' + item.filename,
          isDir: item.longname && item.longname[0] === 'd',
          size: item.attrs.size || 0,
          modified: item.attrs.mtime ? new Date(item.attrs.mtime * 1000).toISOString() : null,
          permissions: item.longname ? item.longname.substring(0, 10) : ''
        }));
        files.sort((a, b) => {
          if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
          return a.name.localeCompare(b.name);
        });
        res.json({ files });
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Read remote file
  router.get('/files/read', async (req, res) => {
    const { connectionId, path: remotePath } = req.query;
    if (!connectionId || !remotePath) return res.status(400).json({ error: 'connectionId and path are required' });
    try {
      const { conn, sftp } = await getSFTP(connectionId);
      const stat = sftp.stat(remotePath, (err, stats) => {
        if (err) { conn.end(); return res.status(500).json({ error: 'Stat failed: ' + err.message }); }
        if (stats.size > 10 * 1024 * 1024) { conn.end(); return res.status(413).json({ error: 'File too large (max 10MB)' }); }
        const readStream = sftp.createReadStream(remotePath);
        let content = '';
        readStream.on('data', (chunk) => { content += chunk.toString('utf8'); });
        readStream.on('end', () => {
          conn.end();
          res.json({ path: remotePath, content, size: stats.size });
        });
        readStream.on('error', (err) => {
          conn.end();
          res.status(500).json({ error: 'Read failed: ' + err.message });
        });
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Write remote file
  router.post('/files/write', async (req, res) => {
    const { connectionId, path: remotePath, content } = req.body || {};
    if (!connectionId || !remotePath) return res.status(400).json({ error: 'connectionId and path are required' });
    try {
      const { conn, sftp } = await getSFTP(connectionId);
      const writeStream = sftp.createWriteStream(remotePath);
      writeStream.write(content || '');
      writeStream.end();
      writeStream.on('close', () => {
        conn.end();
        res.json({ success: true, path: remotePath, size: (content || '').length });
      });
      writeStream.on('error', (err) => {
        conn.end();
        res.status(500).json({ error: 'Write failed: ' + err.message });
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Delete remote file/dir
  router.post('/files/delete', async (req, res) => {
    const { connectionId, path: remotePath } = req.body || {};
    if (!connectionId || !remotePath) return res.status(400).json({ error: 'connectionId and path are required' });
    try {
      const { conn, sftp } = await getSFTP(connectionId);
      // Try file delete first, if fails try dir delete
      sftp.unlink(remotePath, (err) => {
        if (err) {
          sftp.rmdir(remotePath, (err2) => {
            conn.end();
            if (err2) return res.status(500).json({ error: 'Delete failed: ' + err2.message });
            res.json({ success: true, path: remotePath });
          });
        } else {
          conn.end();
          res.json({ success: true, path: remotePath });
        }
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Mkdir remote
  router.post('/files/mkdir', async (req, res) => {
    const { connectionId, path: remotePath } = req.body || {};
    if (!connectionId || !remotePath) return res.status(400).json({ error: 'connectionId and path are required' });
    try {
      const { conn, sftp } = await getSFTP(connectionId);
      sftp.mkdir(remotePath, (err) => {
        conn.end();
        if (err) return res.status(500).json({ error: 'Mkdir failed: ' + err.message });
        res.json({ success: true, path: remotePath });
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Rename remote
  router.post('/files/rename', async (req, res) => {
    const { connectionId, oldPath, newPath } = req.body || {};
    if (!connectionId || !oldPath || !newPath) return res.status(400).json({ error: 'connectionId, oldPath, newPath are required' });
    try {
      const { conn, sftp } = await getSFTP(connectionId);
      sftp.rename(oldPath, newPath, (err) => {
        conn.end();
        if (err) return res.status(500).json({ error: 'Rename failed: ' + err.message });
        res.json({ success: true, oldPath, newPath });
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Download remote file
  router.get('/files/download', async (req, res) => {
    const { connectionId, path: remotePath } = req.query;
    if (!connectionId || !remotePath) return res.status(400).json({ error: 'connectionId and path are required' });
    try {
      const { conn, sftp } = await getSFTP(connectionId);
      const filename = path.basename(remotePath);
      res.setHeader('Content-Disposition', 'attachment; filename="' + filename + '"');
      const readStream = sftp.createReadStream(remotePath);
      readStream.pipe(res);
      readStream.on('error', (err) => {
        conn.end();
        res.status(500).json({ error: 'Download failed: ' + err.message });
      });
      readStream.on('end', () => conn.end());
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Upload to remote VPS
  router.post('/files/upload', upload.single('file'), async (req, res) => {
    const { connectionId, path: remoteDir } = req.body || {};
    if (!connectionId || !req.file) return res.status(400).json({ error: 'connectionId and file are required' });
    try {
      const { conn, sftp } = await getSFTP(connectionId);
      const remotePath = remoteDir 
        ? (remoteDir.endsWith('/') ? remoteDir + req.file.originalname : remoteDir + '/' + req.file.originalname)
        : req.file.originalname;
      const writeStream = sftp.createWriteStream(remotePath);
      writeStream.write(req.file.buffer);
      writeStream.end();
      writeStream.on('close', () => {
        conn.end();
        res.json({ success: true, path: remotePath, name: req.file.originalname, size: req.file.size });
      });
      writeStream.on('error', (err) => {
        conn.end();
        res.status(500).json({ error: 'Upload failed: ' + err.message });
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  return router;
};