#!/usr/bin/env bash
# =============================================================
# deploy.sh — Web Terminal one-shot installer (Ubuntu/Debian)
# Jalankan di VPS baru, dari dalam folder hasil extract zip:
#   cd web-terminal && bash deploy.sh
# Script ini akan: install node+tmux+build tools, npm install,
# lalu menjalankan server sebagai systemd service (auto-start).
# =============================================================
set -e

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$APP_DIR/backend"
SERVICE_NAME="web-terminal"
PORT="$(grep -m1 -o '"port"[[:space:]]*:[[:space:]]*[0-9]*' "$APP_DIR/config/config.json" | grep -o '[0-9]*$' || echo 3000)"

if [ "$(id -u)" -ne 0 ]; then
  SUDO="sudo"
else
  SUDO=""
fi

echo "==> [1/4] Install system dependencies (node 22, tmux, build-essential)..."
if ! command -v node >/dev/null 2>&1 || [ "$(node -v | cut -dv -f2 | cut -d. -f1)" -lt 18 ]; then
  $SUDO apt-get update -y
  $SUDO apt-get install -y curl ca-certificates
  curl -fsSL https://deb.nodesource.com/setup_22.x | $SUDO -E bash -
  $SUDO apt-get install -y nodejs
fi
$SUDO apt-get install -y tmux build-essential python3
echo "    node $(node -v), tmux $(tmux -V)"

echo "==> [2/4] npm install (compile node-pty, butuh beberapa menit)..."
cd "$BACKEND_DIR"
npm install

echo "==> [3/4] Setup systemd service ($SERVICE_NAME)..."
$SUDO tee /etc/systemd/system/$SERVICE_NAME.service > /dev/null <<EOF
[Unit]
Description=Web Terminal (Node.js + tmux)
After=network.target

[Service]
Type=simple
WorkingDirectory=$BACKEND_DIR
ExecStart=$(command -v node) server.js
Restart=always
RestartSec=5
Environment=TERM=xterm-256color
# Ganti ke user non-root jika tidak butuh akses penuh:
User=root

[Install]
WantedBy=multi-user.target
EOF
$SUDO systemctl daemon-reload
$SUDO systemctl enable $SERVICE_NAME
$SUDO systemctl restart $SERVICE_NAME

echo "==> [4/4] Buka firewall port $PORT (jika UFW aktif)..."
if command -v ufw >/dev/null 2>&1 && $SUDO ufw status | grep -q "Status: active"; then
  $SUDO ufw allow $PORT/tcp
  echo "    UFW: port $PORT dibuka"
else
  echo "    UFW tidak aktif — pastikan port $PORT terbuka di security group provider VPS."
fi

sleep 2
STATUS=$($SUDO systemctl is-active $SERVICE_NAME || true)
echo ""
if [ "$STATUS" = "active" ]; then
  IP=$(curl -s --max-time 5 ifconfig.me || hostname -I | awk '{print $1}')
  echo "=============================================="
  echo "  BERHASIL! Web Terminal berjalan."
  echo "  Akses : http://$IP:$PORT"
  echo "  Log   : journalctl -u $SERVICE_NAME -f"
  echo "  Stop  : sudo systemctl stop $SERVICE_NAME"
  echo "=============================================="
else
  echo "  Service belum aktif. Cek log:"
  $SUDO journalctl -u $SERVICE_NAME -n 30 --no-pager
  exit 1
fi
