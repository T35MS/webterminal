web-terminal/
├── backend/
│   ├── server.js          # Main server (auth, WebSocket, tmux)
│   ├── auth.js            # Authentication logic
│   ├── tmux.js            # tmux session management
│   ├── config.js          # Config management (password, settings)
│   └── package.json
├── frontend/
│   ├── index.html         # Login page
│   ├── terminal.html      # Terminal page
│   ├── css/
│   │   ├── login.css
│   │   └── terminal.css
│   └── js/
│       ├── login.js
│       └── terminal.js
├── config/
│   └── config.json        # Default config (password, port, etc)
├── Dockerfile
└── docker-compose.yml
