/* ==========================================================================
   Web Terminal — Login Logic
   ========================================================================== */

(function () {
  'use strict';

  const form = document.getElementById('loginForm');
  const passwordInput = document.getElementById('password');
  const errorMsg = document.getElementById('errorMsg');
  const loginBtn = document.getElementById('loginBtn');
  const btnLabel = loginBtn.querySelector('.btn-label');
  const spinner = loginBtn.querySelector('.spinner');
  const togglePw = document.getElementById('togglePw');

  // Show/hide password toggle
  togglePw.addEventListener('click', function () {
    const isPw = passwordInput.type === 'password';
    passwordInput.type = isPw ? 'text' : 'password';
    togglePw.setAttribute('aria-label', isPw ? 'Hide password' : 'Show password');
  });

  // Hide error when user types
  passwordInput.addEventListener('input', function () {
    if (!errorMsg.hidden) {
      errorMsg.hidden = true;
    }
  });

  // Enter key on the input triggers submit (browser default for single-field form,
  // but we force it to be safe)
  passwordInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      form.requestSubmit();
    }
  });

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    const password = passwordInput.value;

    if (!password) {
      showError('Please enter a password.');
      return;
    }

    setLoading(true);
    hideError();

    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ password: password })
      });

      let data = null;
      const text = await res.text();
      try { data = text ? JSON.parse(text) : null; } catch (_) { /* non-JSON */ }

      if (res.ok) {
        // Store token if returned; backend also sets a cookie
        if (data && data.token) {
          localStorage.setItem('wt_token', data.token);
        }
        window.location.href = '/terminal.html';
        return;
      }

      // Error responses
      const msg = (data && data.error) || (data && data.message) || getHttpError(res.status);
      showError(msg);
    } catch (err) {
      showError('Cannot reach server. Please check your connection and try again.');
    } finally {
      setLoading(false);
    }
  });

  function setLoading(on) {
    loginBtn.disabled = on;
    spinner.hidden = !on;
    btnLabel.textContent = on ? 'Signing in…' : 'Sign In';
  }

  function showError(msg) {
    errorMsg.textContent = msg;
    errorMsg.hidden = false;
    // re-trigger shake animation
    errorMsg.style.animation = 'none';
    void errorMsg.offsetWidth;
    errorMsg.style.animation = '';
  }

  function hideError() {
    errorMsg.hidden = true;
  }

  function getHttpError(status) {
    switch (status) {
      case 401: return 'Incorrect password.';
      case 403: return 'Access denied.';
      case 404: return 'Login endpoint not found.';
      case 429: return 'Too many attempts. Please slow down.';
      case 500: return 'Server error. Please try again later.';
      default: return 'Login failed (HTTP ' + status + ').';
    }
  }

  // Focus password on load
  passwordInput.focus();
})();